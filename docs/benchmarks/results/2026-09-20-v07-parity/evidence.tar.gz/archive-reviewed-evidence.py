"""Run only after every benchmark process has finished; compression uses CPU."""
from pathlib import Path
import json,tarfile,gzip,hashlib,subprocess
r=Path('/private/tmp/xray-v07-parity-20260920');s=r/'source'
out=s/'docs/benchmarks/results/2026-09-20-v07-parity';out.mkdir(parents=True,exist_ok=True)
acceptance=json.loads((r/'reviewed-report-staging/acceptance.json').read_text())
assert len(acceptance['groups'])>=31
for group in acceptance['groups']:
    p=r/'evidence'/group['series']/'manifest.json';m=json.loads(p.read_text())
    assert m.get('finished_unix') and len(m['runs'])==group['runs'],group['series']
    assert (p.parent/'summary.json').exists()
files=set(p for p in (r/'evidence').rglob('*') if p.is_file() and not p.is_symlink())
for pattern in ['*.log','*.json','*.py','*.patch','*.md','*.lock']:
    files.update(p for p in r.glob(pattern) if p.is_file())
for p in (r/'bin').rglob('*'):
    if p.is_file() and not p.is_symlink() and (p.name in {'build.json','source.patch'} or 'runtime-source' in p.parts):files.add(p)
for p in (r/'references').iterdir():
    if p.is_file() and p.suffix in {'.json','.txt'}:files.add(p)
index={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
destination=out/'evidence.tar.gz'
with destination.open('wb') as raw,gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0,compresslevel=6) as compressed,tarfile.open(fileobj=compressed,mode='w|') as archive:
    for p in sorted(files):
        info=archive.gettarinfo(str(p),arcname=str(p.relative_to(r)));info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
        with p.open('rb') as data:archive.addfile(info,data)
(out/'evidence-index.json').write_text(json.dumps({'archive':destination.name,'archive_sha256':hashlib.sha256(destination.read_bytes()).hexdigest(),'file_sha256':index},indent=2)+'\n')
print(json.dumps({'archive':str(destination),'bytes':destination.stat().st_size,'files':len(files)}))

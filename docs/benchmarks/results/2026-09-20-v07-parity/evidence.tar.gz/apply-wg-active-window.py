from pathlib import Path
r=Path('/private/tmp/xray-v07-parity-20260920');d=r/'wg-active-window-source'
p=d/'vendor/smoltcp/src/socket/tcp.rs';t=p.read_text()
def once(a,b):
 global t
 assert t.count(a)==1,a
 t=t.replace(a,b)
once('    receive_window_limit: Option<usize>,','    receive_window_limit: Option<usize>,\n    // Actual receive credit sent on the wire; SYN windows are unscaled.\n    receive_window_end: Option<TcpSeqNumber>,')
once('            receive_window_limit: None,','            receive_window_limit: None,\n            receive_window_end: None,')
once('        self.remote_last_win = 0;','        self.remote_last_win = 0;\n        self.receive_window_end = None;')
once('    /// Set the initial limit before connecting. Once a connection is active,\n    /// only increases are accepted, so already advertised space is not revoked.', '    /// Set the initial limit before connecting. Decreases on active connections\n    /// take effect as previously advertised credit drains; backing storage and\n    /// normal window-scale rounding still bound every advertisement.')
once('        if bytes == old || (self.state != State::Closed && bytes < old) {','        if bytes == old {')
once('''        let limit = self.receive_window_limit.unwrap_or(self.rx_buffer.capacity());
        self.rx_buffer.window().min(limit.saturating_sub(self.rx_buffer.len()))''','''        let Some(limit) = self.receive_window_limit else {
            return self.rx_buffer.window();
        };
        let next_ack = self.remote_seq_no + self.rx_buffer.len();
        let promised = self.receive_window_end.filter(|end| *end > next_ack)
            .map(|end| end - next_ack).unwrap_or(0);
        // Round remaining credit upward when it fits the physical buffer, so
        // rebalancing does not move the advertised right edge backward merely
        // because the next ACK is not aligned to the window scale.
        let unit = 1_usize << self.remote_win_shift;
        let promised = promised.div_ceil(unit) * unit;
        self.rx_buffer.window().min(limit.saturating_sub(self.rx_buffer.len()).max(promised))''')
once('        self.remote_last_win = reply_repr.window_len;','''        self.remote_last_win = reply_repr.window_len;
        if let Some(ack) = reply_repr.ack_number {
            let shift = if reply_repr.control == TcpControl::Syn { 0 } else { self.remote_win_shift };
            self.receive_window_end = Some(ack + ((reply_repr.window_len as usize) << shift));
        }''')
once('        self.remote_last_win = repr.window_len;','''        self.remote_last_win = repr.window_len;
        if let Some(ack) = repr.ack_number {
            let shift = if repr.control == TcpControl::Syn { 0 } else { self.remote_win_shift };
            self.receive_window_end = Some(ack + ((repr.window_len as usize) << shift));
        }''')
once('    fn active_receive_window_only_grows_and_prompts_an_update() {','    fn receive_window_growth_and_budget_changes_prompt_an_update() {')
once('        assert!(!s.set_receive_window_limit(1024));','        s.receive_window_end = Some(REMOTE_SEQ + 1 + 64 * 1024);\n        assert!(s.set_receive_window_limit(1024));')
once('        assert!(!s.set_receive_window_limit(128 * 1024));','        assert!(s.set_receive_window_limit(128 * 1024));')
once('            let original_right_edge = start + 128 * 1024;','            let original_right_edge = start + 128 * 1024;\n            s.receive_window_end = Some(original_right_edge);')
once('        let start = REMOTE_SEQ + 1 + 96 * 1024;','        s.receive_window_end = Some(REMOTE_SEQ + 1 + 128 * 1024);\n        let start = REMOTE_SEQ + 1 + 96 * 1024;')
p.write_text(t)
p=d/'crates/xray-wireguard/src/stack.rs';t=p.read_text()
once('    read_bytes: usize,','    read_bytes: usize,\n    last_read: Option<Clock>,')
once('struct UdpFlow {','''impl TcpFlow {
    fn receives_bulk(&self, socket: &tcp::Socket<'_>, now: Clock) -> bool {
        !self.read_eof
            && self.read_bytes.saturating_add(socket.recv_queue()) >= TCP_INITIAL_RECEIVE_WINDOW / 2
            && (socket.recv_queue() != 0
                || self.last_read.is_some_and(|last| now.saturating_duration_since(last) <= Duration::from_secs(1)))
    }
}
struct UdpFlow {''')
once('''                    !flow.write_eof
                        || self.sockets.get::<tcp::Socket>(flow.handle).send_queue() != 0''','''                    self.sockets.get::<tcp::Socket>(flow.handle).send_queue() != 0''')
once('        let active_receivers = self','        let activity_now = Clock::now();\n        let active_receivers = self')
once('''            .filter(|entry| matches!(entry, Entry::Tcp(flow) if !flow.read_eof))''','''            .filter(|entry| match entry {
                Entry::Tcp(flow) => flow.receives_bulk(self.sockets.get::<tcp::Socket>(flow.handle), activity_now),
                Entry::Udp(_) => false,
            })''')
once('''                    // Wait for actual data before growing beyond the initial
                    // window, so concurrent connects do not each advertise the
                    // entire high-BDP buffer. Window growth remains monotonic.
                    if flow.read_bytes >= TCP_INITIAL_RECEIVE_WINDOW / 2 {
                        progress |= socket.set_receive_window_limit(receive_budget);
                    }''','''                    // Idle keepalive connections do not divide an active flow's
                    // budget. Rebalancing preserves outstanding advertised credit
                    // until it drains, including data sent before a new flow opens.
                    let window = if flow.receives_bulk(socket, activity_now) {
                        receive_budget
                    } else {
                        TCP_INITIAL_RECEIVE_WINDOW
                    };
                    progress |= socket.set_receive_window_limit(window);''')
once('''                                    flow.read_bytes = flow.read_bytes.saturating_add(n);''','''                                    if flow.last_read.is_some_and(|last| activity_now.saturating_duration_since(last) > Duration::from_secs(1)) {
                                        flow.read_bytes = 0;
                                    }
                                    flow.read_bytes = flow.read_bytes.saturating_add(n);
                                    flow.last_read = Some(activity_now);''')
once('                        read_bytes: 0,','                        read_bytes: 0,\n                        last_read: None,')
p.write_text(t)
print('applied active-flow budgets with retained receive credit')

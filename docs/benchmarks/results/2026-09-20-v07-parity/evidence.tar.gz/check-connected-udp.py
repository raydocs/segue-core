from pathlib import Path
import socket,json,platform,time
out=[]
with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as server, socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as client:
 server.bind(('127.0.0.1',0));server.settimeout(1);client.bind(('127.0.0.1',0));client.connect(server.getsockname())
 for name in ('send','sendto','sendmsg_destination','sendmsg_connected'):
  data=name.encode()
  try:
   if name=='send':n=client.send(data)
   elif name=='sendto':n=client.sendto(data,server.getsockname())
   elif name=='sendmsg_destination':n=client.sendmsg([data],[],0,server.getsockname())
   else:n=client.sendmsg([data])
   actual,peer=server.recvfrom(1024);assert n==len(data) and actual==data and peer==client.getsockname()
   out.append({'call':name,'status':'pass','payload_verified':True})
  except OSError as e:out.append({'call':name,'status':'error','errno':e.errno,'message':str(e)})
report={'platform':platform.platform(),'time_unix':time.time(),'functional_only':True,'results':out}
Path('/private/tmp/xray-v07-parity-20260920/connected-udp-platform-check.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))

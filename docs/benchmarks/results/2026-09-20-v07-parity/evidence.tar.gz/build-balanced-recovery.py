"""Run only after jitter/idle timed screen exits; build one combined candidate."""
from pathlib import Path
import os,subprocess,json,time,shutil,hashlib
r=Path('/private/tmp/xray-v07-parity-20260920');s=r/'wg-active-window-source';q=r/'quinn-standard-bbr';rows=[]
env=dict(os.environ,CARGO_BUILD_JOBS='4')
for key in ['RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','CARGO_PROFILE_RELEASE_DEBUG','CARGO_PROFILE_RELEASE_STRIP']:env.pop(key,None)
def run(name,args,cwd=None,expected=0):
 start=time.time();print('START',name,flush=True)
 with (r/(name+'.log')).open('w') as f:code=subprocess.call(args,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT)
 rows.append({'name':name,'command':args,'returncode':code,'seconds':time.time()-start})
 (r/'balanced-recovery-build.json').write_text(json.dumps(rows,indent=2)+'\n');print('END',name,code,flush=True)
 if code!=expected:raise SystemExit(code or 1)
 return (r/(name+'.log')).read_text()
env['CARGO_TARGET_DIR']=str(r/'smol-active-window-test-build')
flags=['--no-default-features','--features','std,medium-ip,proto-ipv4,proto-ipv6,socket-tcp,socket-tcp-reno,socket-udp','--lib']
base=['cargo','test','--offline','--manifest-path',str(s/'vendor/smoltcp/Cargo.toml'),*flags]
t=run('wg-active-window-red-v3',base+['receive_budget_reduction_drains','--','--nocapture'],expected=101)
assert '0 passed; 1 failed;' in t and 'old credit should drain before the smaller budget renews it' in t
run('apply-wg-active-window',['python3',str(r/'apply-wg-active-window.py')])
run('wg-active-window-format',['cargo','fmt','--all'],s)
# The standalone manifest is not a workspace member; format it explicitly too.
run('wg-active-window-vendor-format',['cargo','fmt','--manifest-path',str(s/'vendor/smoltcp/Cargo.toml'),'--all'])
t=run('wg-active-window-vendor',base);assert '448 passed;' in t
(s/'vendor/smoltcp/Cargo.lock').unlink(missing_ok=True)
env['CARGO_TARGET_DIR']=str(r/'wg-active-window-test-build')
t=run('wg-active-window-unit',['cargo','test','--offline','--locked','--release','-p','xray-wireguard','--lib'],s)
assert '8 passed;' in t
run('wg-active-window-add',['git','add','crates/xray-wireguard/src/stack.rs','vendor/smoltcp/src/socket/tcp.rs'],s)
run('wg-active-window-commit',['git','-c','user.name=Codex','-c','user.email=codex@local','commit','-m','Experiment: exclude idle flows from WireGuard budgets and retain advertised TCP credit'],s)
env['CARGO_TARGET_DIR']=str(r/'quinn-standard-test-build')
base=['cargo','test','--offline','--locked','--release','--manifest-path',str(q/'Cargo.toml'),'--no-default-features','--features','rustls-ring','--lib']
t=run('bbr-standard-profile-before',base+['standard_profile_tests','--','--nocapture'],expected=101)
assert '0 passed; 2 failed;' in t and 'standard BBR returns to estimated bandwidth' in t and 'standard startup should not queue nearly three BDP' in t
p=q/'src/congestion/bbr/mod.rs';t=p.read_text()
for a,b in [('cwnd_gain: K_DEFAULT_HIGH_GAIN,','cwnd_gain: K_DERIVED_HIGH_CWNDGAIN,'),('high_cwnd_gain: K_DEFAULT_HIGH_GAIN,','high_cwnd_gain: K_DERIVED_HIGH_CWNDGAIN,')]:
 # Match complete lines to avoid changing high_cwnd_gain in the first replacement.
 old='            '+a;assert t.count(old)==1;t=t.replace(old,'            '+b)
a='const DRAIN_TO_TARGET: bool = true;';assert t.count(a)==1
t=t.replace(a,'// Standard quiche/sing-quic profile: bound the low-gain phase to an RTT\n// even when reverse-path ACK delay keeps flight above the minimum-RTT BDP.\nconst DRAIN_TO_TARGET: bool = false;');p.write_text(t)
run('bbr-standard-format',['cargo','fmt','--manifest-path',str(q/'Cargo.toml'),'--all'])
t=run('bbr-standard-green',base);assert '287 passed;' in t
combined=r/'balanced-source';assert not combined.exists()
run('balanced-clone',['git','clone','--shared',str(s),str(combined)])
paths=['src/congestion.rs','src/congestion/bbr/mod.rs','src/connection/mod.rs','src/connection/packet_builder.rs','src/connection/spaces.rs','src/connection/pacing.rs','src/congestion/bbr/bw_estimation.rs','src/tests/mod.rs','src/tests/congestion_sent.rs']
for name in paths:shutil.copy2(q/name,combined/'vendor/quinn-proto'/name)
run('balanced-add',['git','add','vendor/quinn-proto'],combined)
run('balanced-commit',['git','-c','user.name=Codex','-c','user.email=codex@local','commit','-m','Experiment: combine corrected QUIC delivery pacing with standard BBR profile and active WireGuard budgets'],combined)
env['CARGO_TARGET_DIR']=str(r/'balanced-build')
run('balanced-build',['cargo','build','--offline','--locked','--release','-p','xray-cli'],combined)
b=r/'bin/balanced';b.mkdir();shutil.copy2(r/'balanced-build/release/xray-rust',b/'xray-rust')
patch=subprocess.check_output(['git','diff','--binary','2cefea70f72de26831abd9d85edb414f3acc37cd','HEAD'],cwd=combined);(b/'source.patch').write_bytes(patch)
meta={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=combined,text=True).strip(),'source_tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=combined,text=True).strip(),'clean':not subprocess.check_output(['git','status','--porcelain'],cwd=combined,text=True).strip(),'binary_sha256':hashlib.sha256((b/'xray-rust').read_bytes()).hexdigest(),'patch_base':'2cefea70f72de26831abd9d85edb414f3acc37cd','patch_sha256':hashlib.sha256(patch).hexdigest(),'isolated_fresh_target':env['CARGO_TARGET_DIR'],'experimental':True,'vendor_provenance_not_regenerated':True}
(b/'build.json').write_text(json.dumps(meta,indent=2)+'\n');print('BALANCED READY',flush=True)

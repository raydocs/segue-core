"""Retain symbols for a diagnostic-only profile of the measured RTT source."""
from pathlib import Path
import subprocess, os, json, hashlib, shutil
r=Path('/private/tmp/xray-v07-parity-20260920');s=r/'rtt-source';target=r/'rtt-profile-build'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=s,text=True).strip()=='8fa3aa8f110551b79e320b757d32a845a292592e'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=s,text=True).strip()
env=dict(os.environ,CARGO_TARGET_DIR=str(target),CARGO_BUILD_JOBS='4',CARGO_PROFILE_RELEASE_STRIP='none',CARGO_PROFILE_RELEASE_DEBUG='1')
for key in ['RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS']:
    env.pop(key,None)
with (r/'rtt-profile-build.log').open('w') as log:
    subprocess.run(['cargo','build','--offline','--locked','--release','-p','xray-cli'],cwd=s,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
b=r/'bin/rtt-profile';b.mkdir()
shutil.copy2(target/'release/xray-rust',b/'xray-rust')
for dsym in (target/'release').glob('xray-rust*.dSYM'):
    shutil.copytree(dsym,b/dsym.name)
metadata={'source_commit':'8fa3aa8f110551b79e320b757d32a845a292592e','source_tree':'3960ee1891f77019eda0698c470e00bbd032e1ab',
          'clean':True,'purpose':'symbolized CPU profile only; excluded from performance comparisons',
          'binary_sha256':hashlib.sha256((b/'xray-rust').read_bytes()).hexdigest(),
          'profile_overrides':{'strip':'none','debug':1}}
(b/'build.json').write_text(json.dumps(metadata,indent=2)+'\n')
print('diagnostic binary ready',flush=True)

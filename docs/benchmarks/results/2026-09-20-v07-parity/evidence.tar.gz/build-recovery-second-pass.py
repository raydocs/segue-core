"""Validate and build the next causal variants after the functional screen exits."""
from pathlib import Path
import os,subprocess,json,time
r=Path('/private/tmp/xray-v07-parity-20260920');rows=[]
env=dict(os.environ,CARGO_TARGET_DIR=str(r/'quinn-accounting-test-build'),CARGO_BUILD_JOBS='4')
def run(name,args,expected=0,cwd=None):
    start=time.time();print('START',name,flush=True)
    with (r/(name+'.log')).open('w') as f:code=subprocess.call(args,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT)
    rows.append({'name':name,'command':args,'returncode':code,'seconds':time.time()-start})
    (r/'recovery-second-pass-build.json').write_text(json.dumps(rows,indent=2)+'\n')
    print('END',name,code,flush=True)
    if code!=expected:raise SystemExit(code or 1)
    return (r/(name+'.log')).read_text()
d=r/'quinn-packet-wakeup'
base=['cargo','test','--offline','--locked','--release','--manifest-path',str(d/'Cargo.toml'),
      '--no-default-features','--features','rustls-ring','--lib']
text=run('pacer-packet-wakeup-red',base+['packet_wakeup_regression','--','--nocapture'],101)
assert '0 passed; 1 failed;' in text,text[-2000:]
run('apply-pacer-packet-wakeup',['python3',str(r/'prepare-pacer-packet-wakeup.py'),'--apply-fix'])
run('format-pacer-packet-wakeup',['cargo','fmt','--manifest-path',str(d/'Cargo.toml'),'--all'])
text=run('pacer-packet-wakeup-green',base)
assert '284 passed;' in text,text[-2000:]
s=(r/'build-delivery-paced.py').read_text().replace("r / 'delivery-paced-source'", "r / 'packet-wakeup-source'").replace("r / 'delivery-paced-green.log'", "r / 'pacer-packet-wakeup-green.log'").replace('282 passed;', '284 passed;').replace("r / 'quinn-delivery-paced'", "r / 'quinn-packet-wakeup'").replace("r / 'bin/delivery-paced'", "r / 'bin/packet-wakeup'").replace("r / 'build-delivery-paced.log'", "r / 'build-packet-wakeup.log'").replace('Experiment: BBR delivery sampling and controller-rate pacing','Experiment: preserve BBR pacing capacity across coarse timer wakeups')
(r/'build-packet-wakeup.py').write_text(s)
run('freeze-packet-wakeup',['python3',str(r/'build-packet-wakeup.py')])
env['CARGO_TARGET_DIR']=str(r/'smol-recovery-test-build')
flags=['--no-default-features','--features','std,medium-ip,proto-ipv4,proto-ipv6,socket-tcp,socket-tcp-reno,socket-udp','--lib']
text=run('smol-advanced-recovery-red',['cargo','test','--offline','--locked','--manifest-path',str(r/'smol-recovery/Cargo.toml'),*flags,'advanced_recovery_regression','--','--nocapture'],101)
assert '0 passed; 2 failed;' in text,text[-4000:]
run('wg-shared-window-vendor',['cargo','test','--offline','--locked','--manifest-path',str(r/'wg-shared-window-source/vendor/smoltcp/Cargo.toml'),*flags])
s=(r/'build-wg-shared-send.py').read_text().replace('wg-shared-send','wg-shared-window').replace("['git','add','crates/xray-wireguard/src/stack.rs']", "['git','add','crates/xray-wireguard/src/stack.rs','vendor/smoltcp/src/socket/tcp.rs']").replace('Experiment: bound aggregate WireGuard TCP application send backlog','Experiment: grow WireGuard receive windows within a shared flow budget')
(r/'build-wg-shared-window.py').write_text(s)
run('freeze-wg-shared-window',['python3',str(r/'build-wg-shared-window.py')])

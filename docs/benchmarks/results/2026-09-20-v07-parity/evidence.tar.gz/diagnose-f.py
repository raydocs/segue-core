from pathlib import Path
import importlib.util,json,shutil,subprocess,hashlib
r=Path('/private/tmp/xray-v07-parity-20260920');s=r/'source';out=r/'evidence/f-wireguard-diagnostic';out.mkdir()
b=r/'bin/f-diag';b.mkdir();shutil.copy2('/private/tmp/xray-v07-bench-20260919/build/release/xray-rust',b/'xray-rust')
(b/'source.patch').write_bytes(subprocess.check_output(['git','diff','HEAD','--binary'],cwd=s))
(b/'build.json').write_text(json.dumps({'sha256':hashlib.sha256((b/'xray-rust').read_bytes()).hexdigest(),'diagnostic_only':True}))
spec=importlib.util.spec_from_file_location('parity',s/'scripts/run-v07-protocol-parity.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
with m.bench.fixture(r/'bin/xray-core',out/'server') as configs:
 req={'path':'socks','traffic':'full-duplex','connections':16,'iterations':512,'payload_size':65536,'binary':str(b/'xray-rust'),'config':configs['wireguard'],'output':str(out/'run'),'warmup':True}
 m.bench.save(out/'request.json',req)
 result=m.bench.execute([str(r/'bin/d/xray-bench'),'protocol-run',str(out/'request.json')],out/'driver.log',s)
 m.bench.save(out/'execution.json',result)
(out/'quality.json').write_text(json.dumps({'usable_for_performance':False,'reason':'TCP/queue diagnostic logging enabled; diagnostic only'})+'\n')
print(result['returncode'])

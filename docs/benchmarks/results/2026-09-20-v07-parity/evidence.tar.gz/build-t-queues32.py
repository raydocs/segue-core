from pathlib import Path
import subprocess,os,shutil
r=Path('/private/tmp/xray-v07-parity-20260920');s=r/'source';p=s/'crates/xray-wireguard/src/client.rs'
shutil.copy2(p,r/'s-client.rs')
t=p.read_text().replace('const IP_PACKET_QUEUE: usize = 16;', 'const IP_PACKET_QUEUE: usize = 32;').replace('const STREAM_BUFFER: usize = 32 * 1024;', 'const STREAM_BUFFER: usize = 64 * 1024;').replace('limits.packet_reservations = 128;', 'limits.packet_reservations = 256;').replace('limits.io_queue_packets = 8;', 'limits.io_queue_packets = 16;').replace('''        // 120 data reservations cover five eight-packet engine queues, both
        // sixteen-packet inner queues, the handshake backlog and in-flight I/O.''','''        // 248 data reservations cover five sixteen-packet engine queues, both
        // 32-packet inner queues, one IP batch, the handshake backlog and I/O.''')
p.write_text(t)
p=s/'crates/xray-wireguard/src/io.rs';shutil.copy2(p,r/'s-io.rs');t=p.read_text();old='            let _ = socket.set_recv_buffer_size(7 * 1024 * 1024);';assert old in t
t=t.replace(old,old+'\n            let _ = socket.set_send_buffer_size(7 * 1024 * 1024);').replace('matches the pinned wireguard-go receive-buffer request.', 'matches both pinned wireguard-go socket-buffer requests.')
p.write_text(t)
env=os.environ.copy();env.update(CARGO_TARGET_DIR='/private/tmp/xray-v07-bench-20260919/build',CARGO_BUILD_JOBS='4')
for name,args in [('t-queues32-fmt',['cargo','fmt','--all']),('t-queues32-unit',['cargo','test','--offline','-p','xray-wireguard','--lib']),('t-queues32-build',['cargo','build','--offline','--release','-p','xray-cli','-p','xray-bench'])]:
    with (r/(name+'.log')).open('w') as f:code=subprocess.call(args,cwd=s,env=env,stdout=f,stderr=subprocess.STDOUT)
    print(name,code,flush=True)
    if code:raise SystemExit(code)

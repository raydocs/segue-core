"""Build two immutable bounded-burst choices after all timed work has stopped."""
from pathlib import Path
import subprocess,os,json,time,hashlib,shutil
r=Path('/private/tmp/xray-v07-parity-20260920');s=r/'wg-burst-tuning-source';target=r/'wg-burst-tuning-build'
assert not s.exists() and not target.exists()
subprocess.run(['git','clone','--quiet','--no-local',str(r/'wg-egress-burst-source'),str(s)],check=True)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=s,text=True).strip()=='1f01fa50a80cab3f49a280606846bbb5ee90c812'
env=dict(os.environ,CARGO_TARGET_DIR=str(target),CARGO_BUILD_JOBS='4')
for key in ('RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','CARGO_PROFILE_RELEASE_DEBUG','CARGO_PROFILE_RELEASE_STRIP','XRAY_WIREGUARD_BINARY','NATIVE_WIREGUARD_BINARY'):env.pop(key,None)
rows=[]
def run(name,args):
 start=time.time();print('START',name,flush=True)
 with (r/(name+'.log')).open('w') as log:code=subprocess.call(args,cwd=s,env=env,stdout=log,stderr=subprocess.STDOUT)
 rows.append(dict(name=name,command=args,returncode=code,seconds=time.time()-start));(r/'wg-burst-tuning-checks.json').write_text(json.dumps(rows,indent=2)+'\n')
 print('END',name,code,flush=True)
 if code:raise SystemExit(code)
 return (r/(name+'.log')).read_text()
p=s/'vendor/smoltcp/src/iface/interface/mod.rs';t=p.read_text()
assert 'assert!((1..=8).contains(&packets));' in t
t=t.replace('between one and eight packets.','between one and thirty-two packets.').replace('assert!((1..=8).contains(&packets));','assert!((1..=32).contains(&packets));');p.write_text(t)
p=s/'crates/xray-wireguard/src/stack.rs';t=p.read_text()
assert t.count('interface.set_tcp_egress_burst(8);')==1
t=t.replace('interface.set_tcp_egress_burst(8);','interface.set_tcp_egress_burst(16);',1)
assert '[(1, 32), (8, 32), (8, 1)]' in t
t=t.replace('[(1, 32), (8, 32), (8, 1)]','[(1, 128), (8, 128), (16, 128), (32, 128), (8, 1), (16, 1), (32, 1)]',1)
old='''            for handle in handles {
                sockets
                    .get_mut::<tcp::Socket>(handle)
                    .send_slice(&[42; 16 * 1024])
                    .unwrap();
            }'''
new='''            for handle in handles {
                let socket = sockets.get_mut::<tcp::Socket>(handle);
                // Exercise scheduler bounds independently of the initial Reno
                // window; production sockets keep Reno and its congestion cap.
                socket.set_congestion_control(tcp::CongestionControl::None);
                socket.send_slice(&[42; 64 * 1024]).unwrap();
            }'''
assert old in t;t=t.replace(old,new,1);p.write_text(t)
run('wg-burst-tuning-format',['cargo','fmt','--all'])
run('wg-burst-tuning-unit',['cargo','test','--offline','--locked','--release','-p','xray-wireguard','--lib'])
run('wg-burst-tuning-clippy',['cargo','clippy','--offline','--locked','--release','-p','xray-wireguard','--all-targets','--','-D','warnings'])
for count in [16,32]:
 if count==32:
  p=s/'crates/xray-wireguard/src/stack.rs';t=p.read_text();assert t.count('interface.set_tcp_egress_burst(16);')==1
  p.write_text(t.replace('interface.set_tcp_egress_burst(16);','interface.set_tcp_egress_burst(32);',1))
  run('wg-burst32-unit',['cargo','test','--offline','--locked','--release','-p','xray-wireguard','--lib'])
 run(f'wg-burst{count}-add',['git','add','crates/xray-wireguard/src/stack.rs','vendor/smoltcp/src/iface/interface/mod.rs'])
 run(f'wg-burst{count}-commit',['git','-c','user.name=Codex','-c','user.email=codex@local','commit','-m',f'Evaluate bounded {count}-packet WireGuard TCP egress bursts'])
 run(f'wg-burst{count}-build',['cargo','build','--offline','--locked','--release','-p','xray-cli'])
 b=r/f'bin/wg-burst{count}';b.mkdir();shutil.copy2(target/'release/xray-rust',b/'xray-rust')
 patch=subprocess.check_output(['git','diff','--binary','2cefea70f72de26831abd9d85edb414f3acc37cd','HEAD'],cwd=s);(b/'source.patch').write_bytes(patch)
 meta={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=s,text=True).strip(),'source_tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=s,text=True).strip(),'clean':not subprocess.check_output(['git','status','--porcelain'],cwd=s,text=True).strip(),'binary_sha256':hashlib.sha256((b/'xray-rust').read_bytes()).hexdigest(),'patch_base':'2cefea70f72de26831abd9d85edb414f3acc37cd','patch_sha256':hashlib.sha256(patch).hexdigest(),'isolated_target_for_this_source_root':str(target),'burst_packets':count,'experimental':True,'vendor_provenance_not_regenerated':True}
 (b/'build.json').write_text(json.dumps(meta,indent=2)+'\n')
print('BOUNDED BURST16/32 READY',flush=True)

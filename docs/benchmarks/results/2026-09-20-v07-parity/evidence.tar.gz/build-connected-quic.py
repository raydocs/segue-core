from pathlib import Path
import os,subprocess,json,time,hashlib,shutil
r=Path('/private/tmp/xray-v07-parity-20260920');s=r/'connected-quic-source';target=r/'connected-quic-build'
env=dict(os.environ,CARGO_TARGET_DIR=str(target),CARGO_BUILD_JOBS='4')
for key in ('RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','CARGO_PROFILE_RELEASE_DEBUG','CARGO_PROFILE_RELEASE_STRIP','XRAY_HYSTERIA_BINARY','NATIVE_HYSTERIA_BINARY'):env.pop(key,None)
rows=[]
def run(name,args,expected=0):
 start=time.time();print('START',name,flush=True)
 with (r/(name+'.log')).open('w') as log:code=subprocess.call(args,cwd=s,env=env,stdout=log,stderr=subprocess.STDOUT)
 rows.append({'name':name,'command':args,'returncode':code,'seconds':time.time()-start});(r/'connected-quic-build-checks.json').write_text(json.dumps(rows,indent=2)+'\n')
 print('END',name,code,flush=True)
 if code!=expected:raise SystemExit(code or 1)
 return (r/(name+'.log')).read_text()
run('connected-quic-format',['cargo','fmt','--all'])
t=run('connected-quic-unit',['cargo','test','--offline','--locked','--release','-p','xray-transport','--lib'])
for name in ['connected_ipv4_preserves_payload_ecn_and_dscp','connected_ipv6_preserves_payload_ecn_and_dscp']:assert name+' ... ok' in t
run('connected-quic-client',['cargo','test','--offline','--locked','--release','-p','xray-transport','--test','hysteria_client_tests'])
for label,binary,variable in [('xray',r/'bin/xray-core','XRAY_HYSTERIA_BINARY'),('native',r/'bin/native-hysteria','NATIVE_HYSTERIA_BINARY')]:
 env.pop('XRAY_HYSTERIA_BINARY',None);env.pop('NATIVE_HYSTERIA_BINARY',None);env[variable]=str(binary.resolve())
 run('connected-quic-interop-'+label,['cargo','test','--offline','--locked','--release','-p','xray-transport','--test','hysteria_interop_tests','--','--ignored','--nocapture'])
env.pop('NATIVE_HYSTERIA_BINARY',None)
run('connected-quic-add',['git','add','crates/xray-transport'])
run('connected-quic-commit',['git','-c','user.name=Codex','-c','user.email=codex@local','commit','-m','Experiment with connected macOS Hysteria UDP sends while preserving ECN and rebind'])
run('connected-quic-build',['cargo','build','--offline','--locked','--release','-p','xray-cli'])
b=r/'bin/connected-quic';b.mkdir();shutil.copy2(target/'release/xray-rust',b/'xray-rust')
patch=subprocess.check_output(['git','diff','--binary','2cefea70f72de26831abd9d85edb414f3acc37cd','HEAD'],cwd=s);(b/'source.patch').write_bytes(patch)
meta={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=s,text=True).strip(),'source_tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=s,text=True).strip(),'clean':not subprocess.check_output(['git','status','--porcelain'],cwd=s,text=True).strip(),'binary_sha256':hashlib.sha256((b/'xray-rust').read_bytes()).hexdigest(),'patch_base':'2cefea70f72de26831abd9d85edb414f3acc37cd','patch_sha256':hashlib.sha256(patch).hexdigest(),'isolated_fresh_target':str(target),'experimental':True,'vendor_provenance_not_regenerated':True}
(b/'build.json').write_text(json.dumps(meta,indent=2)+'\n');print('CONNECTED QUIC READY',flush=True)

from pathlib import Path
import subprocess,os
r=Path('/private/tmp/xray-v07-parity-20260920');s=r/'source';env=os.environ.copy();env.update(CARGO_TARGET_DIR='/private/tmp/xray-v07-bench-20260919/build',CARGO_BUILD_JOBS='4')
subprocess.run(['python3',str(r/'prepare-s-ipbatch.py')],check=True)
for name,args in [('s-ipbatch-fmt',['cargo','fmt','--all']),('s-ipbatch-unit',['cargo','test','--offline','-p','xray-wireguard','--lib']),('s-ipbatch-build',['cargo','build','--offline','--release','-p','xray-cli','-p','xray-bench'])]:
    with (r/(name+'.log')).open('w') as f:code=subprocess.call(args,cwd=s,env=env,stdout=f,stderr=subprocess.STDOUT)
    print(name,code,flush=True)
    if code:raise SystemExit(code)

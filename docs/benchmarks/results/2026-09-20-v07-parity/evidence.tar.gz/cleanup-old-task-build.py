"""Recover reproducible task-only Cargo cache after all timing ends."""
from pathlib import Path
import json,hashlib,shutil,time
r=Path('/private/tmp/xray-v07-parity-20260920');old=Path('/private/tmp/xray-v07-bench-20260919');cache=old/'build'
assert cache.is_dir() and not cache.is_symlink() and cache.resolve()==cache
assert (cache/'.rustc_info.json').is_file() and (cache/'release/.fingerprint').is_dir()
binroots=[r/'bin',old/'bin',Path('/private/tmp/xray-v07-opt-20260919/bin')]
# Frozen runtime artifacts may not depend on files in the target cache.
for root in binroots:
 for path in root.rglob('*'):
  if path.is_symlink():assert not path.resolve().is_relative_to(cache),path
checks={}
for file in ('xray-rust','xray-bench'):
 p=cache/'release'/file
 if not p.exists():continue
 digest=hashlib.sha256(p.read_bytes()).hexdigest();matches=[]
 for root in binroots:
  for frozen in root.rglob(file):
   if frozen.is_file() and frozen.stat().st_size==p.stat().st_size and hashlib.sha256(frozen.read_bytes()).hexdigest()==digest:matches.append(str(frozen))
 assert matches,('cache binary has not been frozen',file,digest)
 checks[file]={'sha256':digest,'frozen_matches':matches}
assert checks
before=shutil.disk_usage(r).free
shutil.rmtree(cache)
after=shutil.disk_usage(r).free
(r/'old-task-cache-removal.json').write_text(json.dumps({'removed':str(cache),'frozen_binary_checks':checks,'source_and_evidence_preserved':True,'free_bytes_before':before,'free_bytes_after':after,'time_unix':time.time()},indent=2)+'\n')
print('Freed MiB',round((after-before)/2**20),'available MiB',round(after/2**20))

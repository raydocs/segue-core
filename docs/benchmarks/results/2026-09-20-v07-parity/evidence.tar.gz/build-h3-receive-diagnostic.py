from pathlib import Path
import subprocess,os,hashlib,json,shutil
r=Path(__file__).resolve().parent;s=r/'wg-upload-diagnostic-source';target=r/'wg-upload-diagnostic-build'
env=dict(os.environ,CARGO_TARGET_DIR=str(target),CARGO_BUILD_JOBS='4',CARGO_PROFILE_RELEASE_STRIP='none',CARGO_PROFILE_RELEASE_DEBUG='1')
subprocess.run(['cargo','fmt','--all'],cwd=s,check=True)
with (r/'h3-receive-diagnostic-build.log').open('w') as log:
 subprocess.run(['cargo','build','--offline','--locked','--release','-p','xray-cli'],cwd=s,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
subprocess.run(['git','add','vendor/quinn/src/connection.rs','vendor/quinn-proto/src/connection/assembler.rs'],cwd=s,check=True)
subprocess.run(['git','-c','user.name=Codex','-c','user.email=codex@local','commit','-qm','Diagnostic only: identify retained H3 receive buffers'],cwd=s,check=True)
b=r/'bin/h3-receive-diagnostic';b.mkdir();shutil.copy2(target/'release/xray-rust',b/'xray-rust')
patch=subprocess.check_output(['git','diff','--binary','79a7f18359825d4fb34e14e50de6fe82ff8acb76','HEAD'],cwd=s);(b/'source.patch').write_bytes(patch)
meta=dict(source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=s,text=True).strip(),source_tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=s,text=True).strip(),binary_sha256=hashlib.sha256((b/'xray-rust').read_bytes()).hexdigest(),patch_base='79a7f18359825d4fb34e14e50de6fe82ff8acb76',patch_sha256=hashlib.sha256(patch).hexdigest(),diagnostic_only=True,performance_evidence=False)
(b/'build.json').write_text(json.dumps(meta,indent=2)+'\n')
text=(r/'profile-h3-allocation-stacks.py').read_text().replace("binary=r/'bin/accepted/xray-rust'","binary=r/'bin/h3-receive-diagnostic/xray-rust'").replace("out=r/'evidence/h3-allocation-stacks'","out=r/'evidence/h3-receive-diagnostic'").replace("client_env={'MallocStackLogging':'1'}","client_env={}")
text=text.replace("('stacks',['malloc_history',str(pid),'-allBySize'])","('vmmap',['vmmap','-summary',str(pid)])")
driver=r/'profile-h3-receive-diagnostic.py';driver.write_text(text)
print('BUILD COMPLETE, START DIAGNOSTIC',flush=True)
subprocess.run(['python3','-u',str(driver)],cwd=r,check=True)

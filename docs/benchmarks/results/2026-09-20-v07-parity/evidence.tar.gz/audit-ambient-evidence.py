"""Supplement original observations; never rewrite raw manifests or quality logs."""
from pathlib import Path
import json
r=Path(__file__).resolve().parent
names={'xcodebuild','ANECompilerService'}
extra={'wg-rx-reuse-long-tcp-8','quic-ack-wan-duplex-1','bbr-margin-wan-bulk-1','zero-cid-wan-bulk-1','zero-cid-wan-sustained-1','probe-round-long-duplex-8'}
groups={}
for p in sorted((r/'evidence').glob('*/manifest.json')):
 if not p.parent.name.startswith(('rc-parity-','reviewed-parity-')) and p.parent.name not in extra:continue
 m=json.loads(p.read_text());hits=[]
 for run in m['runs']:
  seen={}
  for snap in run.get('ambient_cpu',{}).get('snapshots',[]):
   for proc in snap['processes']:
    name=Path(proc['executable']).name
    if name in names and proc['cpu']>=10:seen[name]=max(seen.get(name,0),proc['cpu'])
  if seen:hits.append(dict(case=run['case'],version=run['version'],repeat=run['repeat'],maximum_observed_cpu_percent=seen))
 groups[p.parent.name]=dict(complete=bool(m.get('finished_unix')),runs=len(m['runs']),additional_activity_observed=bool(hits),observations=hits)
gates={}
for name in ['v05','v06']:
 p=r/('reviewed-'+name+'-gate-quality.json')
 value=json.loads(p.read_text());hits=[]
 for snapshot in value['snapshots']:
  if not snapshot.get('benchmark_process_present'):continue
  found=[process for process in snapshot['processes'] if Path(process['executable']).name in names and process['cpu']>=10]
  if found:hits.append(dict(time_unix=snapshot['time_unix'],processes=found))
 gates[name]=dict(additional_activity_observed=bool(hits),observations=hits)
result=dict(purpose='Supplement the original explicit compiler set with Xcode build-controller and Apple neural-model compiler observations. These indicate potentially confounding activity, not proof of a specific project compilation or cause of performance differences.',threshold_cpu_percent=10,additional_process_names=sorted(names),original_quality_records_unchanged=True,groups=groups,historical_gates=gates)
(r/'ambient-evidence-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v['observations'] for k,v in groups.items() if v['additional_activity_observed']},indent=2))

from pathlib import Path
import os,subprocess,json,time,shutil,hashlib
r=Path('/private/tmp/xray-v07-parity-20260920');d=r/'quinn-pacer-jitter';rows=[]
env=dict(os.environ,CARGO_TARGET_DIR=str(r/'quinn-pacer-jitter-test-build'),CARGO_BUILD_JOBS='4')
for key in ['RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','CARGO_PROFILE_RELEASE_DEBUG','CARGO_PROFILE_RELEASE_STRIP']:env.pop(key,None)
def run(name,args,cwd=None,expected=0):
 start=time.time();print('START',name,flush=True)
 with (r/(name+'.log')).open('w') as f:code=subprocess.call(args,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT)
 rows.append({'name':name,'command':args,'returncode':code,'seconds':time.time()-start})
 (r/'jitter-idle-build.json').write_text(json.dumps(rows,indent=2)+'\n');print('END',name,code,flush=True)
 if code!=expected:raise SystemExit(code or 1)
 return (r/(name+'.log')).read_text()
base=['cargo','test','--offline','--locked','--release','--manifest-path',str(d/'Cargo.toml'),'--no-default-features','--features','rustls-ring','--lib']
old=r/'pacer-jitter-red.log'
if old.exists():shutil.copy2(old,r/'pacer-jitter-red-setup-error.log')
t=run('pacer-jitter-red-v2',base+['scheduling_jitter_regression','--','--nocapture'],expected=101)
assert '0 passed; 1 failed;' in t and 'scheduling jitter discarded delivery credit' in t
p=d/'src/connection/pacing.rs';t=p.read_text()
a='u128::from(rate) * BURST_INTERVAL_NANOS';assert t.count(a)==1;t=t.replace(a,'u128::from(rate) * RATE_BURST_INTERVAL_NANOS')
a='const BURST_INTERVAL_NANOS: u128 = 2_000_000; // 2ms';assert t.count(a)==1;t=t.replace(a,a+'\n\n// BBR supplies an explicit wire rate. Preserve up to four milliseconds of\n// credit when receive processing or the scheduler delays a one-ms wakeup.\n// The common 256-packet ceiling still bounds every burst.\nconst RATE_BURST_INTERVAL_NANOS: u128 = 4_000_000;')
t=t.replace('assert_eq!(p.capacity, 40_000);','assert_eq!(p.capacity, 80_000);').replace('sent <= rate / 5 + 25_000,','sent <= rate / 5 + p.capacity,')
p.write_text(t)
run('pacer-jitter-format',['cargo','fmt','--manifest-path',str(d/'Cargo.toml'),'--all'])
t=run('pacer-jitter-green',base);assert '285 passed;' in t
s=r/'pacer-jitter-source';assert not s.exists()
run('pacer-jitter-clone',['git','clone','--shared',str(r/'packet-wakeup-source'),str(s)])
run('pacer-jitter-checkout',['git','checkout','--detach','4d77ab4ed82b822c5730dea4b98c1a6d6769223b'],s)
shutil.copy2(p,s/'vendor/quinn-proto/src/connection/pacing.rs')
run('pacer-jitter-add',['git','add','vendor/quinn-proto/src/connection/pacing.rs'],s)
run('pacer-jitter-commit',['git','-c','user.name=Codex','-c','user.email=codex@local','commit','-m','Experiment: retain bounded BBR pacing credit across scheduler jitter'],s)
env['CARGO_TARGET_DIR']=str(r/'pacer-jitter-build')
run('pacer-jitter-build',['cargo','build','--offline','--locked','--release','-p','xray-cli'],s)
b=r/'bin/pacer-jitter';b.mkdir();shutil.copy2(r/'pacer-jitter-build/release/xray-rust',b/'xray-rust')
patch=subprocess.check_output(['git','diff','--binary','2cefea70f72de26831abd9d85edb414f3acc37cd','HEAD'],cwd=s);(b/'source.patch').write_bytes(patch)
meta={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=s,text=True).strip(),'source_tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=s,text=True).strip(),'clean':not subprocess.check_output(['git','status','--porcelain'],cwd=s,text=True).strip(),'binary_sha256':hashlib.sha256((b/'xray-rust').read_bytes()).hexdigest(),'patch_base':'2cefea70f72de26831abd9d85edb414f3acc37cd','patch_sha256':hashlib.sha256(patch).hexdigest(),'isolated_fresh_target':env['CARGO_TARGET_DIR'],'experimental':True,'vendor_provenance_not_regenerated':True}
(b/'build.json').write_text(json.dumps(meta,indent=2)+'\n')
s=r/'source';env['CARGO_TARGET_DIR']=str(r/'idle-harness-build')
run('idle-harness-format',['cargo','fmt','--all'],s)
t=run('idle-harness-unit',['cargo','test','--offline','--locked','--release','-p','xray-bench','--lib','protocol_bench::tests'],s)
assert '3 passed;' in t
run('idle-harness-build',['cargo','build','--offline','--locked','--release','-p','xray-bench'],s)
b=r/'bin/idle-harness';b.mkdir();shutil.copy2(r/'idle-harness-build/release/xray-bench',b/'xray-bench')
patch=subprocess.check_output(['git','diff','--binary','HEAD'],cwd=s);(b/'source.patch').write_bytes(patch)
meta={'source_base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=s,text=True).strip(),'patch_sha256':hashlib.sha256(patch).hexdigest(),'binary_sha256':hashlib.sha256((b/'xray-bench').read_bytes()).hexdigest(),'isolated_fresh_target':env['CARGO_TARGET_DIR'],'purpose':'same protocol workloads, optional verified idle TCP connections, defaults unchanged'}
(b/'build.json').write_text(json.dumps(meta,indent=2)+'\n');print('ALL READY',flush=True)

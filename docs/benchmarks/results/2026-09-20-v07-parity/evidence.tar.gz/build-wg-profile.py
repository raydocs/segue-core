"""Retain symbols for a diagnostic-only profile of the measured T source."""
from pathlib import Path
import subprocess, os, json, hashlib, shutil
r=Path('/private/tmp/xray-v07-parity-20260920');s=r/'source';target=r/'wg-profile-build'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=s,text=True).strip()=='2cefea70f72de26831abd9d85edb414f3acc37cd'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=s,text=True).strip()
env=dict(os.environ,CARGO_TARGET_DIR=str(target),CARGO_BUILD_JOBS='4',CARGO_PROFILE_RELEASE_STRIP='none',CARGO_PROFILE_RELEASE_DEBUG='1')
for key in ['RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS']:
    env.pop(key,None)
with (r/'wg-profile-build.log').open('w') as log:
    subprocess.run(['cargo','build','--offline','--release','-p','xray-cli'],cwd=s,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
b=r/'bin/wg-profile';b.mkdir()
shutil.copy2(target/'release/xray-rust',b/'xray-rust')
for dsym in (target/'release').glob('xray-rust*.dSYM'):
    shutil.copytree(dsym,b/dsym.name)
metadata={'source_commit':'2cefea70f72de26831abd9d85edb414f3acc37cd','source_tree':'2d1a68b00985136c3f4749982239366129428075',
          'clean':True,'purpose':'symbolized CPU profile only; excluded from performance comparisons',
          'binary_sha256':hashlib.sha256((b/'xray-rust').read_bytes()).hexdigest(),
          'profile_overrides':{'strip':'none','debug':1}}
(b/'build.json').write_text(json.dumps(metadata,indent=2)+'\n')
print('diagnostic binary ready',flush=True)

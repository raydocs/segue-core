#!/usr/bin/env python3
"""Report every reference comparison against strict per-metric targets.

A point-estimate loss is never relabeled as a pass because of a broad tolerance.
Paired bootstrap intervals describe uncertainty; they do not prove equality.
"""
import argparse
import importlib.util
import json
from pathlib import Path
import random
import statistics
SPEC=importlib.util.spec_from_file_location('summary',Path(__file__).with_name('summarize-v07-performance.py'))
base=importlib.util.module_from_spec(SPEC);SPEC.loader.exec_module(base)


def ratio_interval(candidate,reference):
    if len(candidate)<3 or len(candidate)!=len(reference) or statistics.median(reference)==0:return None
    rng=random.Random(6928);values=[];n=len(candidate)
    for _ in range(4000):
        indexes=rng.choices(range(n),k=n);den=statistics.median(reference[i] for i in indexes)
        if den:values.append(statistics.median(candidate[i] for i in indexes)/den)
    values.sort()
    return [values[int(.025*len(values))],values[min(len(values)-1,int(.975*len(values)))]] if values else None


def summarize(root):
    summary=base.summarize(root);manifest=json.loads((root/'manifest.json').read_text());extra={}
    for run in manifest['runs']:
        if run['returncode']:continue
        data=json.loads((root/run['output_relative']/'result.json').read_text())
        lat=data.get('latency_us') or {};row=extra.setdefault((run['case'],run['version']),{})
        for k in ['p95','p99']:
            if k in lat:row.setdefault('latency_'+k+'_us',[]).append(lat[k])
    for row in summary['rows']:
        for version,group in row['versions'].items():
            if group['complete']:
                for name,vals in extra.get((row['case'],version),{}).items():
                    if len(vals)==manifest['repeats']:group['metrics'][name]={'median':statistics.median(vals),'min':min(vals),'max':max(vals),'samples':vals}
        row['comparisons']={}
        current=row['versions'].get('candidate')
        if not current:continue
        for name,ref in row['versions'].items():
            if name=='candidate':continue
            compare={'complete':current['complete'] and ref['complete'],'metrics':{}}
            row['comparisons'][name]=compare
            if not compare['complete']:continue
            for metric in sorted(current['metrics'].keys() & ref['metrics'].keys()):
                a=current['metrics'][metric];b=ref['metrics'][metric];den=b['median'];ratio=a['median']/den if den else None
                lower=metric!='throughput_mib_s';strict=metric=='rss_mib'
                meets=(a['median']<den if strict else a['median']<=den if lower else a['median']>=den)
                compare['metrics'][metric]={'candidate':a['median'],'reference':den,'ratio':ratio,'meets_point_target':meets,'paired_bootstrap_95pct':ratio_interval(a['samples'],b['samples'])}
    return summary


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);a=p.parse_args();summary=summarize(a.root)
    (a.root/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'cases':len(summary['rows']),'failures':summary['failures'],'comparisons_with_point_deficits':sum(any(not m['meets_point_target'] for m in c['metrics'].values()) for row in summary['rows'] for c in row['comparisons'].values())},indent=2))

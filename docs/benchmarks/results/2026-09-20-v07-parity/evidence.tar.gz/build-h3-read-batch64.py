"""One bounded larger-batch control; execute only after all timed runs stop."""
from pathlib import Path
import subprocess,os,time,json,hashlib,shutil
r=Path(__file__).resolve().parent;s=r/'h3-read-batch-source';target=r/'h3-read-batch-build'
assert subprocess.check_output(['git','status','--porcelain'],cwd=s,text=True)==''
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=s,text=True).strip()=='c33e77b3cfab18780056b3537bbca2cf8d92c442'
p=s/'crates/xray-transport/src/stream/xhttp/h3.rs';t=p.read_text()
assert t.count('const MAX_RESPONSE_BATCH_BYTES: usize = 16 * 1024;')==1
t=t.replace('const MAX_RESPONSE_BATCH_BYTES: usize = 16 * 1024;','const MAX_RESPONSE_BATCH_BYTES: usize = 64 * 1024;')
t=t.replace('const MAX_RESPONSE_BATCH_CHUNKS: usize = 16;','const MAX_RESPONSE_BATCH_CHUNKS: usize = 64;');p.write_text(t)
env={k:v for k,v in os.environ.items() if not k.startswith(('CARGO_PROFILE_','XRAY_','NATIVE_')) and k not in ('RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','TOKIO_WORKER_THREADS','GOMAXPROCS')}
env.update(CARGO_TARGET_DIR=str(target),CARGO_BUILD_JOBS='4');rows=[]
def run(name,args):
    print('START',name,flush=True);started=time.time()
    with (r/('h3-read-batch64-'+name+'.log')).open('w') as log:code=subprocess.call(args,cwd=s,env=env,stdout=log,stderr=subprocess.STDOUT)
    rows.append(dict(name=name,command=args,returncode=code,seconds=time.time()-started));(r/'h3-read-batch64-build-checks.json').write_text(json.dumps(rows,indent=2)+'\n')
    print('END',name,code,flush=True)
    if code:raise SystemExit(code)
run('format',['cargo','fmt','--all'])
run('tests',['cargo','test','--offline','--locked','--release','-p','xray-transport','--lib','--test','stream_xhttp_h3_tests','--test','stream_xhttp_transport_tests'])
run('clippy',['cargo','clippy','--offline','--locked','--release','-p','xray-transport','--all-targets','--','-D','warnings'])
run('add',['git','add','crates/xray-transport/src/stream/xhttp/h3.rs'])
run('commit',['git','-c','user.name=Codex','-c','user.email=codex@local','commit','-qm','Measure bounded 64 KiB H3 response batching'])
run('build',['cargo','build','--offline','--locked','--release','-p','xray-cli'])
assert subprocess.check_output(['git','status','--porcelain'],cwd=s,text=True)==''
b=r/'bin/h3-read-batch64';b.mkdir();shutil.copy2(target/'release/xray-rust',b/'xray-rust')
base='293ac161e8009645083dbc15e2465f4c600d3ce8';patch=subprocess.check_output(['git','diff','--binary',base,'HEAD'],cwd=s);(b/'source.patch').write_bytes(patch)
meta=dict(source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=s,text=True).strip(),source_tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=s,text=True).strip(),clean=True,binary_sha256=hashlib.sha256((b/'xray-rust').read_bytes()).hexdigest(),patch_base=base,patch_sha256=hashlib.sha256(patch).hexdigest(),isolated_target=str(target),experimental=True,performance_acceptance='pending',change='At most 64 KiB and 64 immediately ready H3 response chunks per one-slot channel handoff; no wait for future data')
(b/'build.json').write_text(json.dumps(meta,indent=2)+'\n')
print('64 KiB CANDIDATE READY',flush=True)

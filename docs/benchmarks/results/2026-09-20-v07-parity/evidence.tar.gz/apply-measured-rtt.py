from pathlib import Path
r=Path('/private/tmp/xray-v07-parity-20260920');q=r/'quinn-rtt-samples'
p=q/'src/congestion/bbr/mod.rs';t=p.read_text();start=t.index('    fn account_delivery(');end=t.index('    fn enter_startup_mode',start)
t=t[:start]+'''    fn update_min_rtt(&mut self, now: Instant, sample: Duration, app_limited: bool) {
        if sample.is_zero() {
            return;
        }
        let expired = self.is_min_rtt_expired(now, app_limited);
        let lower = self.min_rtt.is_zero() || sample < self.min_rtt;
        if lower || expired {
            // Only a fresh measurement can refresh this window: the path's
            // all-time minimum cannot track increases after a route change.
            self.min_rtt = sample;
            // Preserve expiry until the end-of-ACKs probe decision. Refreshing
            // the epoch here would silently cancel the required probe.
            if lower && !expired {
                self.min_rtt_sample_epoch = Some(now);
            }
        }
    }

'''+t[end:]
assert t.count('self.account_delivery(now, bytes, app_limited, rtt);')==2
t=t.replace('self.account_delivery(now, bytes, app_limited, rtt);','self.acked_bytes += bytes;')
# RTT arguments remain in legacy delivery callbacks for API compatibility,
# but only the dedicated fresh-sample callback updates BBR's timing model.
start=t.index('impl Controller for Bbr {');end=t.index('    fn on_end_acks(',start)
part=t[start:end].replace('        rtt: &RttEstimator,','        _rtt: &RttEstimator,')
mark=part.index('    fn on_ack_with_token(')
part=part[:mark]+part[mark:].replace('        app_limited: bool,','        _app_limited: bool,',1)
t=t[:start]+part+'''    fn on_rtt_sample(&mut self, now: Instant, rtt: Duration, app_limited: bool) {
        self.update_min_rtt(now, rtt, app_limited);
    }

'''+t[end:]
t=t.replace('probe_rtt_last_started_at','min_rtt_sample_epoch')
t=t.replace('// First ACK-batch epoch, then the start of the last periodic probe.','// Epoch of the current minimum sample or periodic RTT probe.')
a='''                Some(exit_time) if is_round_start && now >= exit_time => {
                    if !self.is_at_full_bandwidth {'''
b='''                Some(exit_time) if is_round_start && now >= exit_time => {
                    self.min_rtt_sample_epoch = Some(now);
                    if !self.is_at_full_bandwidth {'''
assert t.count(a)==1;t=t.replace(a,b)
a='''    fn calculate_pacing_rate(&mut self) {
        let bw = self.max_bandwidth.get_estimate();
        if bw == 0 {'''
b='''    fn calculate_pacing_rate(&mut self) {
        let bw = self.max_bandwidth.get_estimate();
        // Do not initialize pacing from the configured, unmeasured RTT prior.
        if bw == 0 || self.min_rtt.is_zero() {'''
assert t.count(a)==1;t=t.replace(a,b);p.write_text(t)
p=q/'src/connection/mod.rs';t=p.read_text()
block='''        self.path.congestion.on_end_acks(
            now,
            self.path.in_flight.bytes,
            self.app_limited,
            self.spaces[space].largest_acked_packet,
        );

'''
assert t.count(block)==1;t=t.replace(block,'')
a='            self.path.rtt.update(ack_delay, rtt);';assert t.count(a)==1
t=t.replace(a,a+'''
            self.path.congestion.on_rtt_sample(now, rtt, self.app_limited);''')
a='        // Must be called before crypto/pto_count are clobbered';assert t.count(a)==1
t=t.replace(a,block+a);p.write_text(t)
print('Applied BBR fresh RTT sampling, with a no-op hook for other controllers.')

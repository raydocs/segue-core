from pathlib import Path
import subprocess, os, shutil, json, time
r=Path('/private/tmp/xray-v07-parity-20260920');s=r/'source'
for name in ['connection.rs','mutex.rs']:
    shutil.copy2(r/'quinn-unlocked/src'/name,s/'vendor/quinn/src'/name)
env=os.environ.copy();env.update(CARGO_TARGET_DIR='/private/tmp/xray-v07-bench-20260919/build',CARGO_BUILD_JOBS='4')
for name,args in [('r-unlocked-fmt',['rustfmt','--edition','2021','vendor/quinn/src/connection.rs','vendor/quinn/src/mutex.rs']),('r-unlocked-build',['cargo','build','--offline','--release','-p','xray-cli','-p','xray-bench'])]:
    with (r/(name+'.log')).open('w') as f:code=subprocess.call(args,cwd=s,env=env,stdout=f,stderr=subprocess.STDOUT)
    print(name,code,flush=True)
    if code:raise SystemExit(code)

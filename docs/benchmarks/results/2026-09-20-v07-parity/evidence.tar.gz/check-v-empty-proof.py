from pathlib import Path
import subprocess,os,shutil,json
r=Path('/private/tmp/xray-v07-parity-20260920');s=r/'source';v=r/'gotatun-pool-admission'
p=v/'src/device/memory.rs';t=p.read_text();marker='    #[test]\n    fn exact_pool_allocation_is_admitted_without_copy_and_recycled() {';assert marker in t
t=t.replace(marker,'''    #[test]
    fn empty_view_cannot_prove_its_backing_allocation_by_address() {
        use crate::packet::PacketBufPool;
        let memory = MemoryBudget::new(DeviceLimits::mobile());
        let pool = PacketBufPool::<4096>::new(1);
        let mut packet = pool.get();
        packet.truncate(0);
        // An empty view can point one past a different allocation adjacent to
        // this pool. A byte belonging to the original allocation is required.
        assert!(packet.pool_allocation_bound().is_none());
        let old = packet.as_ptr();
        let packet = memory.admit(packet, 1420, false).unwrap();
        assert_ne!(packet.as_ptr(), old);
        drop(packet);
        assert_eq!(memory.snapshot().reservations, 0);
    }

'''+marker);p.write_text(t)
env=os.environ.copy();env.update(CARGO_TARGET_DIR='/private/tmp/xray-v07-bench-20260919/build',CARGO_BUILD_JOBS='4')
def run(name,args,red=False):
    print('START',name,flush=True)
    with (r/(name+'.log')).open('w') as f:code=subprocess.call(args,cwd=s,env=env,stdout=f,stderr=subprocess.STDOUT)
    print('END',name,code,flush=True)
    if red:
        log=(r/(name+'.log')).read_text();assert code!=0 and 'test result: FAILED' in log and 'assertion failed: packet.pool_allocation_bound().is_none()' in log
    elif code:raise SystemExit(code)
test=['cargo','test','--offline','--manifest-path',str(v/'Cargo.toml'),'--no-default-features','--features','ring,device','--lib']
run('v-pool-admission-empty-red',test+['empty_view_cannot_prove_its_backing_allocation_by_address'],True)
p=v/'src/packet/pool.rs';t=p.read_text();old='''    pub(super) fn allocation_bound_for(&self, bytes: &[u8]) -> Option<usize> {
''';assert old in t
t=t.replace(old,old+'''        // Empty views have no byte proving allocation membership: their
        // one-past pointer can coincide with the start of an adjacent allocation.
        if bytes.is_empty() {
            return None;
        }
''');p.write_text(t)
files=['src/packet/mod.rs','src/packet/pool.rs','src/device/memory.rs']
run('v-pool-admission-empty-fmt',['rustfmt','--edition','2024',*[str(v/f) for f in files]])
run('v-pool-admission-empty-green',test)
for name in files:shutil.copy2(v/name,s/'vendor/gotatun'/name)
run('v-pool-admission-final-build',['cargo','build','--offline','--release','-p','xray-cli','-p','xray-bench'])

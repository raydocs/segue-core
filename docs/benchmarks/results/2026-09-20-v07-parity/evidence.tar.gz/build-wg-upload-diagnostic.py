"""Diagnostic clone only: aggregate datagram sizes and retain profiling symbols."""
from pathlib import Path
import subprocess, os, json, hashlib, shutil
r=Path('/private/tmp/xray-v07-parity-20260920')
s=r/'wg-upload-diagnostic-source';target=r/'wg-upload-diagnostic-build'
assert not s.exists() and not target.exists()
subprocess.run(['git','clone','--quiet','--no-local',str(r/'wg-batching-source'),str(s)],check=True)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=s,text=True).strip()=='67d322d4ad010a24d738399fa3ea1877a62e6775'
p=s/'crates/xray-wireguard/src/io.rs';t=p.read_text()
anchor='    async fn send_to(&self, packet: Packet, destination: SocketAddr) -> io::Result<()> {\n'
assert t.count(anchor)==1
t=t.replace(anchor,anchor+'        trace_datagram(0, packet.len());\n')
anchor='        packet.truncate(n);\n'
assert t.count(anchor)==1
t=t.replace(anchor,'        trace_datagram(1, n);\n'+anchor)
t+='''
// Diagnostic-only packet-size accounting, absent from the selected runtime.
fn trace_datagram(direction: usize, bytes: usize) {
    use std::sync::atomic::{AtomicU64, Ordering::Relaxed};
    static COUNTS: [[AtomicU64; 6]; 2] = [const { [const { AtomicU64::new(0) }; 6] }; 2];
    static TOTAL: [AtomicU64; 2] = [const { AtomicU64::new(0) }; 2];
    static BYTES: [AtomicU64; 2] = [const { AtomicU64::new(0) }; 2];
    let bucket = [96, 256, 768, 1280, 1452].iter().position(|limit| bytes <= *limit).unwrap_or(5);
    COUNTS[direction][bucket].fetch_add(1, Relaxed);
    BYTES[direction].fetch_add(bytes as u64, Relaxed);
    let count = TOTAL[direction].fetch_add(1, Relaxed) + 1;
    if count.is_multiple_of(16384) {
        let counts: Vec<_> = COUNTS[direction].iter().map(|value| value.load(Relaxed)).collect();
        eprintln!("WG_PACKET_DIAG dir={} count={} bytes={} buckets={:?}", direction, count, BYTES[direction].load(Relaxed), counts);
    }
}
'''
p.write_text(t)
subprocess.run(['cargo','fmt','--all'],cwd=s,check=True)
subprocess.run(['git','add','crates/xray-wireguard/src/io.rs'],cwd=s,check=True)
subprocess.run(['git','-c','user.name=Codex','-c','user.email=codex@local','commit','-qm','Diagnostic only: sample WireGuard upload packet sizes'],cwd=s,check=True)
env=dict(os.environ,CARGO_TARGET_DIR=str(target),CARGO_BUILD_JOBS='4',CARGO_PROFILE_RELEASE_STRIP='none',CARGO_PROFILE_RELEASE_DEBUG='1')
for key in ['RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS']:env.pop(key,None)
with (r/'wg-upload-diagnostic-build.log').open('w') as log:
    subprocess.run(['cargo','build','--offline','--locked','--release','-p','xray-cli'],cwd=s,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
b=r/'bin/wg-upload-diagnostic';b.mkdir()
shutil.copy2(target/'release/xray-rust',b/'xray-rust')
for dsym in (target/'release').glob('xray-rust*.dSYM'):shutil.copytree(dsym,b/dsym.name)
patch=subprocess.check_output(['git','diff','--binary','67d322d4ad010a24d738399fa3ea1877a62e6775','HEAD'],cwd=s)
(b/'diagnostic.patch').write_bytes(patch)
metadata={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=s,text=True).strip(),
          'source_tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=s,text=True).strip(),
          'clean':True,'purpose':'diagnostic packet sizes and symbolized profile only; excluded from performance comparisons',
          'binary_sha256':hashlib.sha256((b/'xray-rust').read_bytes()).hexdigest(),
          'diagnostic_patch_sha256':hashlib.sha256(patch).hexdigest(),
          'profile_overrides':{'strip':'none','debug':1}}
(b/'build.json').write_text(json.dumps(metadata,indent=2)+'\n')
print('diagnostic upload binary ready',flush=True)

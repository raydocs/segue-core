from pathlib import Path
import sys
q=Path(sys.argv[1]);p=q/'src/congestion/bbr/mod.rs';t=p.read_text()
a='    exit_probe_rtt_at: Option<Instant>,';assert t.count(a)==1;t=t.replace(a,a+'\n    // Keep deliberately sparse probing out of the path-capacity filter.\n    probe_limited_until: Option<u64>,')
a='            exit_probe_rtt_at: None,';assert t.count(a)==1;t=t.replace(a,a+'\n            probe_limited_until: None,')
a='''        if self.mode == Mode::ProbeRtt {
            match self.exit_probe_rtt_at {''';b='''        if self.mode == Mode::ProbeRtt {
            // The sender chooses to suppress traffic for this measurement.
            // Keep the mark through the first ACK of post-probe flight.
            self.probe_limited_until = Some(self.max_sent_packet_number);
            match self.exit_probe_rtt_at {''';assert t.count(a)==1;t=t.replace(a,b)
a='''        self.max_bandwidth.on_sent(now, bytes);''';b='''        if self.mode == Mode::ProbeRtt || self.probe_limited_until.is_some() {
            self.max_bandwidth.record_sent(now, bytes, 1, true);
        } else {
            self.max_bandwidth.on_sent(now, bytes);
        }''';assert t.count(a)==1;t=t.replace(a,b)
a='''            .record_sent(now, bytes, in_flight, app_limited)''';b='''            .record_sent(now, bytes, in_flight, app_limited
                || self.mode == Mode::ProbeRtt || self.probe_limited_until.is_some())''';assert t.count(a)==1;t=t.replace(a,b)
a='''        if let Some(largest_acked_packet) = largest_packet_num_acked {
            self.max_acked_packet_number = largest_acked_packet;
        }''';b='''        if let Some(largest_acked_packet) = largest_packet_num_acked {
            self.max_acked_packet_number = largest_acked_packet;
            if self.probe_limited_until.is_some_and(|end| largest_acked_packet > end) {
                self.probe_limited_until = None;
            }
        }''';assert t.count(a)==1;t=t.replace(a,b);p.write_text(t)
p=q/'src/congestion/bbr/bw_estimation.rs';t=p.read_text();a='let app_limited = legacy_app_limited.unwrap_or(batch.app_limited);';b='let app_limited = batch.app_limited || legacy_app_limited.unwrap_or(false);';assert t.count(a)==1;p.write_text(t.replace(a,b))

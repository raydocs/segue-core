from pathlib import Path
import argparse,os,subprocess,json,time,hashlib,shutil
p=argparse.ArgumentParser();p.add_argument('--include-probe',action='store_true');a=p.parse_args()
r=Path('/private/tmp/xray-v07-parity-20260920');s=r/'connected-recovery-source';target=r/'connected-recovery-build'
env=dict(os.environ,CARGO_TARGET_DIR=str(target),CARGO_BUILD_JOBS='4')
for key in ('RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','CARGO_PROFILE_RELEASE_DEBUG','CARGO_PROFILE_RELEASE_STRIP','XRAY_HYSTERIA_BINARY','NATIVE_HYSTERIA_BINARY'):env.pop(key,None)
rows=[]
def run(name,args,expected=0,cwd=None):
 start=time.time();print('START',name,flush=True)
 with (r/(name+'.log')).open('w') as log:code=subprocess.call(args,cwd=cwd or s,env=env,stdout=log,stderr=subprocess.STDOUT)
 rows.append({'name':name,'command':args,'returncode':code,'seconds':time.time()-start});(r/'connected-recovery-build-checks.json').write_text(json.dumps(rows,indent=2)+'\n')
 print('END',name,code,flush=True)
 if code!=expected:raise SystemExit(code or 1)
 return (r/(name+'.log')).read_text()
run('connected-recovery-prepare',['python3',str(r/'prepare-connected-recovery.py')],cwd=r)
t=run('connected-recovery-red',['cargo','test','--offline','--locked','--release','-p','xray-transport','--lib','rejected_mtu_probe_does_not_close_connected_socket','--','--nocapture'],expected=101)
assert '0 passed; 1 failed;' in t and 'a rejected UDP probe must remain nonfatal' in t
run('connected-recovery-apply',['python3',str(r/'apply-connected-recovery.py')])
if a.include_probe:
 for name in ['mod.rs','bw_estimation.rs']:
  shutil.copy2(r/'quinn-probe-limited/src/congestion/bbr'/name,s/'vendor/quinn-proto/src/congestion/bbr'/name)
run('connected-recovery-format',['cargo','fmt','--all'])
# The new macOS dependencies add edges to already pinned workspace packages.
t=run('connected-recovery-green',['cargo','test','--offline','--release','-p','xray-transport','--lib'])
assert '172 passed;' in t and 'rejected_mtu_probe_does_not_close_connected_socket ... ok' in t
run('connected-recovery-client',['cargo','test','--offline','--locked','--release','-p','xray-transport','--test','hysteria_client_tests'])
for label,binary,variable in [('xray',r/'bin/xray-core','XRAY_HYSTERIA_BINARY'),('native',r/'bin/native-hysteria','NATIVE_HYSTERIA_BINARY')]:
 env.pop('XRAY_HYSTERIA_BINARY',None);env.pop('NATIVE_HYSTERIA_BINARY',None);env[variable]=str(binary.resolve())
 run('connected-recovery-interop-'+label,['cargo','test','--offline','--locked','--release','-p','xray-transport','--test','hysteria_interop_tests','--','--ignored','--nocapture'])
env.pop('NATIVE_HYSTERIA_BINARY',None)
run('connected-recovery-clippy',['cargo','clippy','--offline','--locked','--release','-p','xray-transport','--all-targets','--','-D','warnings'])
run('connected-recovery-add',['git','add','Cargo.lock','crates/xray-transport','vendor/quinn-proto/src/congestion/bbr'])
run('connected-recovery-commit',['git','-c','user.name=Codex','-c','user.email=codex@local','commit','-m','Keep QUIC loss recovery on connected UDP sends'+(' and drain ProbeRTT flight' if a.include_probe else '')])
run('connected-recovery-build',['cargo','build','--offline','--locked','--release','-p','xray-cli'])
b=r/'bin/connected-recovery';b.mkdir();shutil.copy2(target/'release/xray-rust',b/'xray-rust')
patch=subprocess.check_output(['git','diff','--binary','2cefea70f72de26831abd9d85edb414f3acc37cd','HEAD'],cwd=s);(b/'source.patch').write_bytes(patch)
meta={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=s,text=True).strip(),'source_tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=s,text=True).strip(),'clean':not subprocess.check_output(['git','status','--porcelain'],cwd=s,text=True).strip(),'binary_sha256':hashlib.sha256((b/'xray-rust').read_bytes()).hexdigest(),'patch_base':'2cefea70f72de26831abd9d85edb414f3acc37cd','patch_sha256':hashlib.sha256(patch).hexdigest(),'isolated_fresh_target':str(target),'experimental':True,'includes_four_packet_probe':a.include_probe,'vendor_provenance_not_regenerated':True}
(b/'build.json').write_text(json.dumps(meta,indent=2)+'\n');print('CONNECTED RECOVERY READY',flush=True)

from pathlib import Path
import os,subprocess,json,time,hashlib,shutil
r=Path('/private/tmp/xray-v07-parity-20260920');q=r/'quinn-probe-rtt'
env=dict(os.environ,CARGO_TARGET_DIR=str(r/'quinn-probe-rtt-test-build'),CARGO_BUILD_JOBS='4')
for key in ('RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','CARGO_PROFILE_RELEASE_DEBUG','CARGO_PROFILE_RELEASE_STRIP'):env.pop(key,None)
rows=[]
def run(name,args,cwd=None,expected=0):
 start=time.time();print('START',name,flush=True)
 with (r/(name+'.log')).open('w') as log:code=subprocess.call(args,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT)
 rows.append({'name':name,'command':args,'returncode':code,'seconds':time.time()-start});(r/'probe-rtt-build-checks.json').write_text(json.dumps(rows,indent=2)+'\n')
 print('END',name,code,flush=True)
 if code!=expected:raise SystemExit(code or 1)
 return (r/(name+'.log')).read_text()
base=['cargo','test','--offline','--locked','--release','--manifest-path',str(q/'Cargo.toml'),'--no-default-features','--features','rustls-ring','--lib']
t=run('probe-rtt-drain-red',base+['probe_rtt_drain_regression','--','--nocapture'],expected=101)
assert '0 passed; 1 failed;' in t and 'RTT measurement must wait for a drained flight' in t
p=q/'src/congestion/bbr/mod.rs';t=p.read_text();a='const PROBE_RTT_BASED_ON_BDP: bool = true;';assert t.count(a)==1;p.write_text(t.replace(a,'// Four datagrams drain a queued path before measuring its propagation RTT.\nconst PROBE_RTT_BASED_ON_BDP: bool = false;'))
run('probe-rtt-format',['cargo','fmt','--manifest-path',str(q/'Cargo.toml'),'--all'])
t=run('probe-rtt-green',base);assert '293 passed;' in t
s=r/'probe-rtt-source';assert not s.exists();run('probe-rtt-clone',['git','clone','--no-local',str(r/'rtt-source'),str(s)])
shutil.copy2(q/'src/congestion/bbr/mod.rs',s/'vendor/quinn-proto/src/congestion/bbr/mod.rs')
run('probe-rtt-add',['git','add','vendor/quinn-proto/src/congestion/bbr/mod.rs'],s)
run('probe-rtt-commit',['git','-c','user.name=Codex','-c','user.email=codex@local','commit','-m','Drain queued flight before measuring BBR propagation RTT'],s)
env['CARGO_TARGET_DIR']=str(r/'probe-rtt-build');run('probe-rtt-build',['cargo','build','--offline','--locked','--release','-p','xray-cli'],s)
b=r/'bin/probe-rtt';b.mkdir();shutil.copy2(r/'probe-rtt-build/release/xray-rust',b/'xray-rust')
patch=subprocess.check_output(['git','diff','--binary','2cefea70f72de26831abd9d85edb414f3acc37cd','HEAD'],cwd=s);(b/'source.patch').write_bytes(patch)
meta={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=s,text=True).strip(),'source_tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=s,text=True).strip(),'clean':not subprocess.check_output(['git','status','--porcelain'],cwd=s,text=True).strip(),'binary_sha256':hashlib.sha256((b/'xray-rust').read_bytes()).hexdigest(),'patch_base':'2cefea70f72de26831abd9d85edb414f3acc37cd','patch_sha256':hashlib.sha256(patch).hexdigest(),'isolated_fresh_target':env['CARGO_TARGET_DIR'],'experimental':True,'vendor_provenance_not_regenerated':True}
(b/'build.json').write_text(json.dumps(meta,indent=2)+'\n');print('PROBE RTT READY',flush=True)

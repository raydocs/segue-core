"""Run only after balanced timed benchmarks finish."""
from pathlib import Path
import os,subprocess,json,time,shutil,hashlib
r=Path('/private/tmp/xray-v07-parity-20260920');q=r/'quinn-rtt-samples'
env=dict(os.environ,CARGO_BUILD_JOBS='4',CARGO_TARGET_DIR=str(r/'quinn-rtt-test-build'))
for key in ['RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','CARGO_PROFILE_RELEASE_DEBUG','CARGO_PROFILE_RELEASE_STRIP']:env.pop(key,None)
rows=[]
def run(name,args,cwd=None,expected=0):
 start=time.time();print('START',name,flush=True)
 with (r/(name+'.log')).open('w') as f:code=subprocess.call(args,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT)
 rows.append({'name':name,'command':args,'returncode':code,'seconds':time.time()-start})
 (r/'rtt-recovery-build.json').write_text(json.dumps(rows,indent=2)+'\n');print('END',name,code,flush=True)
 if code!=expected:raise SystemExit(code or 1)
 return (r/(name+'.log')).read_text()
base=['cargo','test','--offline','--locked','--release','--manifest-path',str(q/'Cargo.toml'),'--no-default-features','--features','rustls-ring','--lib']
t=run('measured-rtt-red',base+['measured_rtt','--','--nocapture'],expected=101)
assert '1 passed; 4 failed;' in t
for expected in ['measured RTT must initialize startup pacing','fresh lower RTT must refresh','expired BBR minimum must use','fresh RTT callback must reach']:assert expected in t,expected
run('apply-measured-rtt',['python3',str(r/'apply-measured-rtt.py')])
run('measured-rtt-format',['cargo','fmt','--manifest-path',str(q/'Cargo.toml'),'--all'])
t=run('measured-rtt-green',base);assert '292 passed;' in t
source=r/'rtt-source';assert not source.exists()
run('rtt-clone',['git','clone','--shared',str(r/'balanced-source'),str(source)])
for path in ['src/congestion.rs','src/congestion/bbr/mod.rs','src/connection/paths.rs','src/connection/mod.rs','src/tests/congestion_sent.rs']:shutil.copy2(q/path,source/'vendor/quinn-proto'/path)
run('rtt-add',['git','add','vendor/quinn-proto'],source)
run('rtt-commit',['git','-c','user.name=Codex','-c','user.email=codex@local','commit','-m','Fix BBR startup pacing and minimum RTT refresh using measured path samples'],source)
env['CARGO_TARGET_DIR']=str(r/'rtt-build')
run('rtt-build',['cargo','build','--offline','--locked','--release','-p','xray-cli'],source)
b=r/'bin/rtt-measured';b.mkdir();shutil.copy2(r/'rtt-build/release/xray-rust',b/'xray-rust')
patch=subprocess.check_output(['git','diff','--binary','2cefea70f72de26831abd9d85edb414f3acc37cd','HEAD'],cwd=source);(b/'source.patch').write_bytes(patch)
meta={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip(),'source_tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=source,text=True).strip(),'clean':not subprocess.check_output(['git','status','--porcelain'],cwd=source,text=True).strip(),'binary_sha256':hashlib.sha256((b/'xray-rust').read_bytes()).hexdigest(),'patch_base':'2cefea70f72de26831abd9d85edb414f3acc37cd','patch_sha256':hashlib.sha256(patch).hexdigest(),'isolated_fresh_target':env['CARGO_TARGET_DIR'],'experimental':True,'vendor_provenance_not_regenerated':True}
(b/'build.json').write_text(json.dumps(meta,indent=2)+'\n');print('MEASURED RTT READY',flush=True)

from pathlib import Path
import os,subprocess,json,time,hashlib,shutil
r=Path('/private/tmp/xray-v07-parity-20260920');s=r/'inline-poller-source';target=r/'inline-poller-build'
env=dict(os.environ,CARGO_TARGET_DIR=str(target),CARGO_BUILD_JOBS='4')
for key in ('RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','CARGO_PROFILE_RELEASE_DEBUG','CARGO_PROFILE_RELEASE_STRIP','XRAY_HYSTERIA_BINARY','NATIVE_HYSTERIA_BINARY'):env.pop(key,None)
rows=[]
def run(name,args,cwd=None):
 start=time.time();print('START',name,flush=True)
 with (r/(name+'.log')).open('w') as log:code=subprocess.call(args,cwd=cwd or s,env=env,stdout=log,stderr=subprocess.STDOUT)
 rows.append({'name':name,'command':args,'returncode':code,'seconds':time.time()-start});(r/'inline-poller-build-checks.json').write_text(json.dumps(rows,indent=2)+'\n');print('END',name,code,flush=True)
 if code:raise SystemExit(code)
 return (r/(name+'.log')).read_text()
run('inline-poller-prepare',['python3',str(r/'prepare-inline-poller.py')],r)
run('inline-poller-format',['cargo','fmt','--all'])
t=run('inline-poller-unit',['cargo','test','--offline','--release','-p','xray-transport','--lib']);assert '172 passed;' in t
run('inline-poller-client',['cargo','test','--offline','--locked','--release','-p','xray-transport','--test','hysteria_client_tests'])
for label,binary,variable in [('xray',r/'bin/xray-core','XRAY_HYSTERIA_BINARY'),('native',r/'bin/native-hysteria','NATIVE_HYSTERIA_BINARY')]:
 env.pop('XRAY_HYSTERIA_BINARY',None);env.pop('NATIVE_HYSTERIA_BINARY',None);env[variable]=str(binary.resolve())
 run('inline-poller-interop-'+label,['cargo','test','--offline','--locked','--release','-p','xray-transport','--test','hysteria_interop_tests','--','--ignored','--nocapture'])
env.pop('NATIVE_HYSTERIA_BINARY',None)
run('inline-poller-clippy',['cargo','clippy','--offline','--locked','--release','-p','xray-transport','--all-targets','--','-D','warnings'])
run('inline-poller-add',['git','add','Cargo.lock','crates/xray-transport'])
run('inline-poller-commit',['git','-c','user.name=Codex','-c','user.email=codex@local','commit','-m','Keep connected UDP writability waiters inline without per-packet allocations'])
run('inline-poller-build',['cargo','build','--offline','--locked','--release','-p','xray-cli'])
b=r/'bin/inline-poller';b.mkdir();shutil.copy2(target/'release/xray-rust',b/'xray-rust')
patch=subprocess.check_output(['git','diff','--binary','2cefea70f72de26831abd9d85edb414f3acc37cd','HEAD'],cwd=s);(b/'source.patch').write_bytes(patch)
meta={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=s,text=True).strip(),'source_tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=s,text=True).strip(),'clean':not subprocess.check_output(['git','status','--porcelain'],cwd=s,text=True).strip(),'binary_sha256':hashlib.sha256((b/'xray-rust').read_bytes()).hexdigest(),'patch_base':'2cefea70f72de26831abd9d85edb414f3acc37cd','patch_sha256':hashlib.sha256(patch).hexdigest(),'isolated_fresh_target':str(target),'experimental':True,'vendor_provenance_not_regenerated':True}
(b/'build.json').write_text(json.dumps(meta,indent=2)+'\n');print('INLINE POLLER READY',flush=True)

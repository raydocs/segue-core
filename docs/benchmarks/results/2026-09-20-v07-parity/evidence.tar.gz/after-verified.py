"""Run manually only after exec23664 and all its child collectors have exited."""
from pathlib import Path
import subprocess,os,json,time
r=Path('/private/tmp/xray-v07-parity-20260920');s=r/'source';rows=[]
env=dict(os.environ,CARGO_TARGET_DIR=str(r/'quinn-accounting-test-build'),CARGO_BUILD_JOBS='4')
for key in ['RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS']:env.pop(key,None)
def run(name,command,expected_failures=0):
    print('START',name,flush=True);started=time.time()
    p=r/(name+'.log')
    with p.open('w') as f:code=subprocess.call(command,cwd=s,env=env,stdout=f,stderr=subprocess.STDOUT)
    rows.append({'name':name,'command':command,'returncode':code,'seconds':time.time()-started})
    (r/'after-verified-pipeline.json').write_text(json.dumps(rows,indent=2)+'\n')
    print('END',name,code,flush=True)
    if expected_failures:
        log=p.read_text()
        assert code and 'test result: FAILED.' in log and f'{expected_failures} failed;' in log,'need actual assertion failures; inspect log before proceeding'
    elif code:raise SystemExit(code)
run('workers6-extra',['python3',str(r/'run-verified-mobile-workers.py')])
run('duplex-long-extra',['python3',str(r/'run-verified-duplex-long.py')])
run('prepare-exact-sent',['python3',str(r/'prepare-quinn-exact-sent.py')])
test=['cargo','test','--offline','--release','--manifest-path',str(r/'quinn-exact-sent/Cargo.toml'),'--no-default-features','--features','rustls-ring','--locked','--lib']
run('exact-sent-red',test+['congestion_sent','--','--nocapture'],expected_failures=2)
run('apply-exact-sent',['python3',str(r/'prepare-quinn-exact-sent.py'),'--apply-fix'])
run('format-exact-sent',['cargo','fmt','--manifest-path',str(r/'quinn-exact-sent/Cargo.toml'),'--all'])
run('exact-sent-green',test)
run('prepare-bbr-cwnd',['python3',str(r/'prepare-bbr-cwnd.py')])
run('bbr-cwnd-red',test+['startup_target_regression','--','--nocapture'],expected_failures=1)
run('apply-bbr-cwnd',['python3',str(r/'prepare-bbr-cwnd.py'),'--apply-fix'])
run('format-bbr-cwnd',['cargo','fmt','--manifest-path',str(r/'quinn-exact-sent/Cargo.toml'),'--all'])
run('bbr-cwnd-green',test)
run('bbr-diagnostic-prepare',['python3',str(r/'prepare-bbr-diagnostic.py')])
run('bbr-diagnostic-runs',['python3',str(r/'run-bbr-diagnostic.py')])

from pathlib import Path
import importlib.util,json
r=Path('/private/tmp/xray-v07-parity-20260920');s=r/'source';out=r/'evidence/b-path-diagnostic-v2';out.mkdir()
spec=importlib.util.spec_from_file_location('parity',s/'scripts/run-v07-protocol-parity.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
with m.bench.fixture(r/'bin/xray-core',out/'server') as configs:
 req={'path':'socks','traffic':'upload','connections':1,'iterations':512,'payload_size':65536,'binary':str(r/'bin/b/xray-rust'),'config':configs['hysteria2'],'output':str(out/'run'),'warmup':True,'client_env':{'XRAY_HY_WINDOW_TRACE':'1'}}
 m.bench.save(out/'request.json',req)
 result=m.bench.execute([str(r/'bin/b/xray-bench'),'protocol-run',str(out/'request.json')],out/'driver.log',s)
 m.bench.save(out/'execution.json',result)
(out/'quality.json').write_text(json.dumps({'usable_for_performance':False,'reason':'per-MiB diagnostics enabled; diagnostic only'})+'\n')
print(result['returncode'])

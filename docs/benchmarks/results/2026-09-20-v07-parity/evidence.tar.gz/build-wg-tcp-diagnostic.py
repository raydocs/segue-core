from pathlib import Path
import subprocess,os,shutil,json,hashlib,time
r=Path('/private/tmp/xray-v07-parity-20260920');d=r/'wg-tcp-diagnostic-source';b=r/'bin/wg-tcp-diagnostic'
assert not b.exists()
env=dict(os.environ,CARGO_TARGET_DIR='/private/tmp/xray-v07-bench-20260919/build',CARGO_BUILD_JOBS='4')
for key in ['TOKIO_WORKER_THREADS','GOMAXPROCS','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS']:env.pop(key,None)
subprocess.run(['cargo','fmt','--all'],cwd=d,env=env,check=True)
start=time.time()
with (r/'build-wg-tcp-diagnostic.log').open('w') as f:
    subprocess.run(['cargo','build','--release','--offline','-p','xray-cli'],cwd=d,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
b.mkdir();binary=b/'xray-rust';shutil.copy2(Path(env['CARGO_TARGET_DIR'])/'release/xray-rust',binary)
patch=subprocess.check_output(['git','diff','--binary','HEAD'],cwd=d);(b/'source.patch').write_bytes(patch)
meta={'source_base':'2cefea70f72de26831abd9d85edb414f3acc37cd','binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),
      'source_patch_sha256':hashlib.sha256(patch).hexdigest(),'seconds':time.time()-start,
      'not_for_performance_comparison':True,'diagnostic':True,
      'counters':['cwnd_bytes','flight_bytes','send_queue_bytes','recv_queue_bytes','peer_window_bytes','srtt_ms','rto_ms',
                  'duplicate_acks','send_ack_seq','sent_high_seq','receive_next_seq','rto_events','fast_retransmit_events',
                  'zero_progress_acks_with_data_and_sack','pending_fast_retransmit']}
(b/'build.json').write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps(meta,indent=2))

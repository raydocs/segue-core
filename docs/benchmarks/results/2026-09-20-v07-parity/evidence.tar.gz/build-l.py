from pathlib import Path
import os,subprocess,json,time
r=Path('/private/tmp/xray-v07-parity-20260920');s=r/'source';e=dict(os.environ,CARGO_TARGET_DIR='/private/tmp/xray-v07-bench-20260919/build',CARGO_BUILD_JOBS='4');rows=[]
plan=[('wireguard-tests',['cargo','test','--offline','--release','-p','xray-wireguard','--lib']),('smoltcp-tests',['cargo','test','--offline','--locked','--release','--manifest-path','vendor/smoltcp/Cargo.toml','--no-default-features','--features','std,medium-ip,proto-ipv4,proto-ipv6,socket-tcp,socket-tcp-reno,socket-udp','--lib']),('build',['cargo','build','--offline','--release','-p','xray-cli','-p','xray-bench'])]
for name,args in plan:
 print('START',name,flush=True);start=time.time()
 with (r/('l-'+name+'.log')).open('w') as f:code=subprocess.call(args,cwd=s,env=e,stdout=f,stderr=subprocess.STDOUT)
 rows.append({'name':name,'returncode':code,'seconds':time.time()-start});(r/'l-build-checks.json').write_text(json.dumps(rows,indent=2));print('END',name,code,flush=True)
 if code:raise SystemExit(code)

from pathlib import Path
p=Path('/private/tmp/xray-v07-parity-20260920/quinn-unlocked/src/connection.rs');t=p.read_text()
start=t.index('    fn drive_transmit(&mut self,');end=t.index('    fn forward_endpoint_events',start)
method=t[start:end].replace('fn drive_transmit(&mut self,','fn drive_transmit(&self,').replace('self.','conn.').replace('match self\n', 'match conn\n').replace('let max_datagrams = self\n', 'let max_datagrams = conn\n')
method=method.replace('''        let now = conn.runtime.now();''','''        let mut conn = self.state.lock("transmit");
        let now = conn.runtime.now();''',1)
method=method.replace('''                    conn.send_buffer.clear();
                    conn.send_buffer.reserve(conn.inner.current_mtu() as usize);
                    match conn
                        .inner
                        .poll_transmit(now, max_datagrams, &mut conn.send_buffer)''','''                    let state = &mut *conn;
                    state.send_buffer.clear();
                    state.send_buffer.reserve(state.inner.current_mtu() as usize);
                    match state
                        .inner
                        .poll_transmit(now, max_datagrams, &mut state.send_buffer)''')
old='''            let retry = match conn
                .socket
                .try_send(&udp_transmit(&t, &conn.send_buffer[..len]))
            {''';new='''            // The driver alone owns this reusable buffer. Let stream readers
            // and writers acquire connection state while the UDP syscall runs;
            // no payload copy, channel or per-packet allocation is needed.
            let socket = conn.socket.clone();
            let buffer = std::mem::take(&mut conn.send_buffer);
            drop(conn);
            let result = socket.try_send(&udp_transmit(&t, &buffer[..len]));
            conn = self.state.lock("transmit result");
            conn.send_buffer = buffer;
            let retry = match result {''';assert old in method;method=method.replace(old,new)
t=t[:start]+t[end:];t=t.replace('impl ConnectionRef {','impl ConnectionRef {\n'+method,1)
t=t.replace('''        let conn = &mut *self.0.state.lock("poll");''','''        let mut conn = self.0.state.lock("poll");''',1)
old='''        let mut keep_going = conn.drive_transmit(cx)?;''';new='''        // Register before releasing state: a stream write/close during UDP
        // transmission must still schedule another poll, including the gap
        // between the last empty transmit poll and reacquiring state below.
        conn.driver = Some(cx.waker().clone());
        drop(conn);
        let mut keep_going = self.0.drive_transmit(cx)?;
        let mut conn = self.0.state.lock("poll after transmit");''';assert old in t;t=t.replace(old,new,1);p.write_text(t)

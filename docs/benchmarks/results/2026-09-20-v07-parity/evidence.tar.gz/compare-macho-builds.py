"""Distinguish Mach-O build UUID/signature changes from executable-content changes."""
from pathlib import Path
import struct,hashlib,json,sys
r=Path('/private/tmp/xray-v07-parity-20260920');name=sys.argv[1]
paths=[r/'bin'/name/'xray-rust',r/'bin'/(name+'-clean')/'xray-rust']
def parse(p):
    b=bytearray(p.read_bytes());head=struct.unpack_from('<8I',b);assert head[0]==0xfeedfacf
    offset=32;sections={};masked=[]
    for _ in range(head[4]):
        cmd,size=struct.unpack_from('<II',b,offset)
        if cmd==0x19:
            segment=struct.unpack_from('<II16sQQQQiiII',b,offset);pos=offset+72
            for _ in range(segment[-2]):
                sec=struct.unpack_from('<16s16sQQ8I',b,pos)
                key=sec[1].rstrip(b'\0').decode()+'/'+sec[0].rstrip(b'\0').decode()
                if sec[4]:sections[key]={'size':sec[3],'sha256':hashlib.sha256(b[sec[4]:sec[4]+sec[3]]).hexdigest()}
                pos+=80
        elif cmd==0x1b:masked.append((offset+8,16,'LC_UUID'))
        elif cmd==0x1d:
            start,length=struct.unpack_from('<II',b,offset+8);masked.append((start,length,'code signature blob'))
        offset+=size
    for start,length,_ in masked:b[start:start+length]=bytes(length)
    return b,sections,masked
old,a,masked_old=parse(paths[0]);new,b,masked_new=parse(paths[1])
report={'original':str(paths[0]),'isolated_rebuild':str(paths[1]),
        'byte_identical':paths[0].read_bytes()==paths[1].read_bytes(),
        'all_executable_sections_identical':a==b,
        'whole_file_identical_except_uuid_and_signature':old==new,
        'masked_old':masked_old,'masked_new':masked_new,
        'sections':{k:{'old':a.get(k),'new':b.get(k),'identical':a.get(k)==b.get(k)} for k in a.keys()|b.keys()}}
(r/(name+'-clean-mach-o-comparison.json')).write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='sections'},indent=2))

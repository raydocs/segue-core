from pathlib import Path
r=Path('/private/tmp/xray-v07-parity-20260920');s=r/'wg-egress-burst-source'
p=s/'vendor/smoltcp/src/iface/interface/mod.rs';t=p.read_text()
anchor='''            let mut neighbor_addr = None;
            let mut respond = |inner: &mut InterfaceInner, meta: PacketMeta, response: Packet| {'''
assert t.count(anchor)==1
t=t.replace(anchor,'''            let mut neighbor_addr = None;
            let mut sent_packets = 0;
            let mut respond = |inner: &mut InterfaceInner, meta: PacketMeta, response: Packet| {''',1)
anchor='''                result = PollResult::SocketStateChanged;

                Ok(())'''
assert t.count(anchor)==1
t=t.replace(anchor,'''                result = PollResult::SocketStateChanged;
                sent_packets += 1;

                Ok(())''',1)
old='''                Socket::Tcp(socket) => {
                    socket.dispatch(&mut self.inner, |inner, meta, (ip, tcp)| {
                        respond(inner, meta, Packet::new(ip, IpPayload::Tcp(tcp)))
                    })
                }'''
new='''                Socket::Tcp(socket) => {
                    let mut status = Ok(());
                    for _ in 0..self.tcp_egress_burst {
                        let mut emitted = false;
                        status = socket.dispatch(&mut self.inner, |inner, meta, (ip, tcp)| {
                            respond(inner, meta, Packet::new(ip, IpPayload::Tcp(tcp)))?;
                            emitted = true;
                            Ok(())
                        });
                        if status.is_err() || !emitted {
                            break;
                        }
                    }
                    status
                }'''
assert t.count(old)==1;t=t.replace(old,new,1)
old='''                        *cursor = index;
                    }
                    break; // Device buffer full: retry this socket first next time.'''
new='''                        // A socket that already sent part of its burst yields
                        // its next turn. With no progress retry this same socket.
                        *cursor = if sent_packets != 0 { index + 1 } else { index };
                    }
                    break; // Device buffer full: preserve bounded round-robin progress.'''
assert t.count(old)==1;t=t.replace(old,new,1);p.write_text(t)

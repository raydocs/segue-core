from pathlib import Path
import subprocess,shutil,os,json,time
r=Path('/private/tmp/xray-v07-parity-20260920');q=r/'quinn-probe-limited'
assert not q.exists();shutil.copytree(r/'probe-rtt-source/vendor/quinn-proto',q)
p=q/'src/congestion/bbr/mod.rs';p.write_text(p.read_text()+(r/'probe-limited-tests.rs').read_text())
env=dict(os.environ,CARGO_TARGET_DIR=str(r/'quinn-probe-limited-test-build'),CARGO_BUILD_JOBS='4');rows=[]
def run(name,args,expected=0):
 start=time.time();print('START',name,flush=True)
 with (r/(name+'.log')).open('w') as log:code=subprocess.call(args,env=env,stdout=log,stderr=subprocess.STDOUT)
 rows.append({'name':name,'command':args,'returncode':code,'seconds':time.time()-start});(r/'probe-limited-checks.json').write_text(json.dumps(rows,indent=2)+'\n');print('END',name,code,flush=True)
 if code!=expected:raise SystemExit(code or 1)
 return (r/(name+'.log')).read_text()
base=['cargo','test','--offline','--locked','--release','--manifest-path',str(q/'Cargo.toml'),'--no-default-features','--features','rustls-ring','--lib']
t=run('probe-limited-red',base+['probe_limited_regression','--','--nocapture'],101)
assert '0 passed; 2 failed;' in t and 'the four-packet ProbeRTT limit is not reduced path capacity' in t and 'the first post-probe flight still spans deliberately limited delivery' in t
run('probe-limited-apply',['python3',str(r/'apply-probe-limited.py'),str(q)])
run('probe-limited-format',['cargo','fmt','--manifest-path',str(q/'Cargo.toml'),'--all'])
t=run('probe-limited-green',base);assert '295 passed;' in t
print('PROBE LIMITED READY: tests only; combined build not yet updated',flush=True)

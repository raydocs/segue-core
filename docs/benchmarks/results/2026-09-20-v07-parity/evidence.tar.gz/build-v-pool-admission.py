from pathlib import Path
import subprocess,os,shutil,json,time
r=Path('/private/tmp/xray-v07-parity-20260920');s=r/'source';v=r/'gotatun-pool-admission';rows=[]
env=os.environ.copy();env.update(CARGO_TARGET_DIR='/private/tmp/xray-v07-bench-20260919/build',CARGO_BUILD_JOBS='4')
def run(name,args,red=False):
    start=time.time();print('START',name,flush=True)
    with (r/(name+'.log')).open('w') as f:code=subprocess.call(args,cwd=s,env=env,stdout=f,stderr=subprocess.STDOUT)
    rows.append(dict(name=name,command=args,returncode=code,seconds=time.time()-start));(r/'v-pool-admission-build.json').write_text(json.dumps(rows,indent=2));print('END',name,code,flush=True)
    if red:
        log=(r/(name+'.log')).read_text()
        assert code!=0 and 'test result: FAILED' in log and 'panicked at' in log and 'admission copied a proven 4096-byte pool allocation' in log, 'RED must fail the actual admission assertion'
    elif code:raise SystemExit(code)
test=['cargo','test','--offline','--manifest-path',str(v/'Cargo.toml'),'--no-default-features','--features','ring,device','--lib']
run('v-pool-admission-red',test+['exact_pool_allocation_is_admitted_without_copy_and_recycled'],red=True)
subprocess.run(['python3',str(r/'prepare-v-pool-admission.py'),'apply'],check=True)
files=['src/packet/mod.rs','src/packet/pool.rs','src/device/memory.rs']
run('v-pool-admission-fmt',['rustfmt','--edition','2024',*[str(v/f) for f in files]])
run('v-pool-admission-green',test)
run('v-pool-admission-no-device',['cargo','check','--offline','--manifest-path',str(v/'Cargo.toml'),'--no-default-features','--features','ring','--lib'])
for name in files:shutil.copy2(v/name,s/'vendor/gotatun'/name)
run('v-pool-admission-build',['cargo','build','--offline','--release','-p','xray-cli','-p','xray-bench'])

"""Assemble complete measured tables; never changes an acceptance decision."""
from pathlib import Path
import json
import shutil

r = Path(__file__).resolve().parent
stage = r / 'rc-parity-report-staging'
out = r / 'source/docs/benchmarks/results/2026-09-20-v07-parity'
a = json.loads((stage / 'acceptance.json').read_text())
build = json.loads((r / 'bin/final-parity/build.json').read_text())
integration = json.loads((r / 'delivery-runtime-integration.json').read_text())
assert integration['delivery_tree'] == build['source_tree']
assert len(a['groups']) >= 31
out.mkdir(parents=True, exist_ok=True)
shutil.copytree(stage, out, dirs_exist_ok=True)
data = out / 'data'
data.mkdir(exist_ok=True)
metadata = [
    'accepted-validation-detail.json', 'accepted-runtime-equivalence.json',
    'final-build-and-gates.json', 'final-v05-gate-quality.json',
    'final-v06-gate-quality.json', 'h3-batching-decision.json',
    'h3-window-decision.json', 'delivery-runtime-integration.json',
    'rc-parity-sequence.json', 'h3-symbol-diagnostic-equivalence.json',
    'h3-heap-sizes-analysis.json', 'h3-receive-diagnostic-analysis.json',
    'wg-egress-ack-diagnostic-analysis.json',
    'reference-socket-budgets.json', 'rc-parity-echo-followup-plan.json',
    'rc-parity-remaining-sequence.json',
]
copied = []
for name in metadata:
    p = r / name
    assert p.is_file(), name
    shutil.copy2(p, data / name)
    copied.append(name)
shutil.copy2(r / 'bin/final-parity/build.json', data / 'selected-build.json')
shutil.copy2(r / 'bin/final-parity/source.patch', out / 'selected-source.patch')
for p in (r / 'references').iterdir():
    if p.is_file() and p.suffix in {'.json', '.txt'}:
        shutil.copy2(p, data / ('reference-' + p.name))


def summary(name):
    return json.loads((r / 'evidence' / name / 'summary.json').read_text())


def link(name):
    return '[' + name.removeprefix('rc-parity-') + '](' + name + '.md)'


def med(version, metric):
    return version['metrics'].get(metric, {}).get('median')


def number(value):
    return '—' if value is None else f'{value:.3f}'


def local_table():
    lines = [
        '| Protocol / workload | Rust MiB/s | Fastest reference MiB/s | Rust CPU ms | Lowest reference CPU ms | Rust RSS MiB | Reference RSS range MiB |',
        '|---|---:|---:|---:|---:|---:|---:|',
    ]
    for protocol in ['hysteria2', 'wireguard']:
        for count in [1, 8]:
            name = f'rc-parity-{protocol}-local-bulk-{count}'
            for row in summary(name)['rows']:
                v = row['versions']; c = v['candidate']
                refs = {k: val for k, val in v.items() if k in {'native', 'singbox', 'xray'}}
                fastest = max(refs, key=lambda k: med(refs[k], 'throughput_mib_s'))
                lowest = min(refs, key=lambda k: med(refs[k], 'cpu_ms'))
                rss = [med(val, 'rss_mib') for val in refs.values()]
                label = row['case'].replace('-socks-', ' / ')
                cells = [f'[{label}]({name}.md)', number(med(c, 'throughput_mib_s')),
                         number(med(refs[fastest], 'throughput_mib_s')) + ' (' + fastest + ')',
                         number(med(c, 'cpu_ms')),
                         number(med(refs[lowest], 'cpu_ms')) + ' (' + lowest + ')',
                         number(med(c, 'rss_mib')), f'{min(rss):.3f}–{max(rss):.3f}']
                lines.append('| ' + ' | '.join(cells) + ' |')
    return lines


external_deficits = [x for x in a['point_deficits'] if x['role'] == 'external_reference']
# Keep startup and internal comparisons too; the full page is the audit trail.
deficit_lines = [
    '# Every point deficit', '',
    'These are all point estimates that miss their declared target, including startup and internal controls. '
    'They are not all statistically resolved regressions. Ratios are candidate/reference; throughput prefers ≥1, '
    'RSS requires <1 and CPU/latency/startup prefer ≤1. Zero CPU ticks cannot prove equality. '
    'Intervals and the checker status are preserved without applying the historical 15% threshold.', '',
    '| Series / case | Comparator | Metric | Candidate | Reference | Ratio | Paired 95% interval |',
    '|---|---|---|---:|---:|---:|---|',
]
for d in a['point_deficits']:
    interval = d.get('paired_bootstrap_95pct')
    cells = [link(d['series']) + ' / ' + d['case'], d['reference_client'] + ' (' + d['role'] + ')',
             d['metric'], number(d.get('candidate')), number(d.get('reference')), number(d.get('ratio')),
             '—' if interval is None else f'[{interval[0]:.5f}, {interval[1]:.5f}]']
    deficit_lines.append('| ' + ' | '.join(cells) + ' |')
(out / 'point-deficits.md').write_text('\n'.join(deficit_lines) + '\n')

failed = sum(g['failed_runs'] for g in a['groups'])
candidate_failed = sum(g['failed_by_version'].get('candidate',0) for g in a['groups'])
total = sum(g['runs'] for g in a['groups'])
contaminated = [g['series'] for g in a['groups'] if g['compiler_interference']]
status = 'MET in the measured scope' if a['all_external_groups_strictly_met'] and not failed and not contaminated else 'NOT established across all measured cases'
lines = [
    '# v0.7 protocol efficiency and regression comparisons', '',
    '**Requested target: lower client memory and no throughput, CPU, latency or reliability loss. '
    f'Overall status: {status}.**', '',
    f'The final frozen candidate completed {total} runs in {len(a["groups"])} groups; '
    f'{failed} failed runs ({candidate_failed} candidate runs) and {len(contaminated)} groups with sampled compiler interference. '
    f'The strict summaries retain {len(external_deficits)} external-comparison metric point deficits. '
    'Functional success, lower RSS and passing historical regression gates do not by themselves establish complete parity. '
    'See [all point deficits](point-deficits.md), [machine-readable acceptance](acceptance.json), '
    'and [every measured client/workload](results-index.md).', '',
    'This directory is named for the start of the investigation, not the finish date of every run. '
    'Per-run Unix timestamps, source identities, full logs and the rejected experiments are retained in the evidence archive.', '',
    '## Pinned reference implementations', '',
    '| Reference | Version / source |', '|---|---|',
    '| Xray-core | v26.7.28 / `5ca6f4b7d4dc20a881d4330e498892697627ec0c` |',
    '| Native Hysteria | app/v2.12.2 / `619a6f856b69fb7ee6a7a379e810e68b84004605` |',
    '| sing-box | v1.13.15 / `3708fa18766cda1f11b77f6ed9c7bd61688f17df` |',
    '| Native WireGuard library adapter | wireguard-go `v0.0.0-20250521234502-f333402bd9cb`; gVisor `v0.0.0-20260122175437-89a5d21be8f0` |', '',
    '[Executable SHA256s](data/reference-builds.json) and adjacent `reference-*-build.txt` '
    'files retain compiler/module identities. These are named pinned versions, not a claim about every later release. '
    'The small WireGuard SOCKS adapter and the two complete clients are separate controls.', '',
    '## Local capacity', '',
    'Medians of three repetitions, two Rust CLI workers and GOMAXPROCS=2. '
    'CPU is steady transfer CPU time for the same validated byte volume, not CPU percentage. '
    'RSS is sampled client-process memory and excludes kernel buffers. '
    'The compact table selects the strongest reference separately for speed and CPU; '
    'linked pages show all clients and JSON retains ranges and intervals.', '',
    *local_table(), '',
    '## Complete series and acceptance', '',
    '| Series | Runs | Failed | Compiler interference | Strict parity status |',
    '|---|---:|---:|---|---|',
]
for g in a['groups']:
    parity = g.get('parity')
    pstatus = parity['status'] if parity and parity.get('reference_comparisons') else 'not an external parity comparison'
    lines.append('| ' + ' | '.join([link(g['series']), str(g['runs']), str(g['failed_runs']), str(g['compiler_interference']), pstatus]) + ' |')
lines += [
    '', 'The worker controls retain their own settings: Rust=2/Go=6, Rust=2/stock-Go, '
    'and Rust=6/Go=6. They are not pooled with the primary Rust=2/Go=2 comparison. '
    'Cold stress has no warmup and tests reliability; it is not external parity evidence.', '',
    '### Hysteria echo follow-up and reference failures', '',
    'The primary 1,000-exchange Hysteria echo series had one native-client UDP8 timeout '
    '(repeat 2, 120-second workload deadline). All 12 candidate runs passed. '
    'The initial serial collector stopped after retaining that complete group; '
    'the original sequence record remains unchanged. The explicit continuation runs '
    'remaining groups independently and retains complete comparator failures.', '',
    'A separate full-client control used five repeats and 5,000 exchanges per connection. '
    'Candidate and sing-box each passed 20/20. Native Hysteria timed out in UDP8 repeats 1, 3, 4, 5; '
    'Xray timed out in UDP8 repeat 4. Cleanup audits passed and no compiler interference was sampled. '
    'No throughput/latency aggregate is synthesized for an incomplete client/workload. '
    'These are observed echo completion failures for the pinned clients with the common Xray server, '
    'not proof of a particular packet-loss location or protocol defect.', '',
    'The short UDP1 series recorded candidate p95 355 µs versus sing-box 329 µs, '
    'with its three-repeat ratio interval above 1. The longer control recorded 130 versus 148 µs. '
    'Candidate UDP1 p99 was 336 versus 331 µs (ratio interval [0.9033, 1.1863]); '
    'candidate TCP1 p99 was 261 versus sing-box 255 µs (interval [0.9686, 1.0785]). '
    'Thus the short-tail loss did not persist unchanged in the longer workload, '
    'while small positive p99 point differences remain unresolved. This is duration sensitivity, '
    'not a reason to erase the short series or claim universal latency parity. '
    'See [the primary series](rc-parity-hysteria2-local-echo.md) and '
    '[the complete follow-up](rc-parity-hysteria2-local-echo-followup.md).', '',
    '## Historical regression checks', '',
    'Both original five-repeat gates passed for the final selected build, using the unchanged scripts and rules. '
    'v0.5: idle 4,256 KiB (limit 5,120), 100 flows 6,624 KiB (7,500), '
    '1,000 flows 23,280 KiB (25,000), TCP 39 µs (55), TUN 5,920 KiB (8,192). '
    'v0.6: process 553.328 MiB/s (≥10), encrypted 283.171 MiB/s (≥264.219), '
    'route 0.218 ms (≤1.201), XHTTP 18.891 MiB (≤64). '
    'Same-run controls determine the encrypted/route numerical limits under the original rules. '
    'Build/gate commands and outcomes are in [the gate record](data/final-build-and-gates.json); '
    'complete raw outputs are archived under `evidence/final-v05-gate` and `evidence/final-v06-gate`.', '',
    'The final legacy, TUN and REALITY comparison uses frozen v0.6.1 '
    '`ed5258a3a589c2a1f9330142f37c8f3d28a640fa`. '
    'The new-protocol TUN comparison uses the earlier fix candidate M '
    '`61373052dc8b6784162c81650faa6bd92f0604aa`, not original v0.7. '
    'The following are historical investigation flags, whose 15% rules do not relax the external target:', '',
    '| Series / workload | Review metrics | Candidate/baseline ratios |',
    '|---|---|---|',
]
for review in a['legacy_review_flags']:
    lines.append('| ' + ' | '.join([link(review['series']) + ' / ' + review['case'], ', '.join(review['metrics']),
                                   ', '.join(f'{k}={v:.4f}' for k, v in review['ratios'].items())]) + ' |')
if not a['legacy_review_flags']:
    lines.append('| No final-series flags | — | — |')
lines += [
    '', 'Earlier 105-run long controls used predecessor `293ac161`, not the final H3 receive fix. '
    'They resolved the short-load VLESS-TLS TUN/REALITY throughput and H2 TUN upload concerns, '
    'but retained H2 download and H3 duplex memory flags. '
    'The separate 4 GiB/flow H2 control completed 18 runs: at one flow candidate RSS was 9.734 MiB '
    'versus 11.781 MiB for v0.6.1; at eight flows 20.203 versus 19.016 MiB, '
    'while throughput was 2,133.727 versus 1,644.850 MiB/s. '
    'This duration sensitivity prevents describing the original short H2 RSS flag as a stable universal increase. '
    'The residual positive point differences remain recorded. H3 final-byte controls and their memory tradeoff are described below.', '',
    '## Changes and measurement method', '',
]
narrative = (r / 'report-narrative-draft.md').read_text()
lines.append(narrative[narrative.index('## What changed'):])
lines += [
    '## Validation and exact source', '',
    'The predecessor `293ac161` passed all 18 validation groups: library/TUN tests, '
    'native and Xray Hysteria/WireGuard interoperability, multi-peer and network changes, '
    'timed WireGuard rekey, restart/replay checks, Clippy, formatting and Python collector tests. '
    '[Exact commands and counts](data/accepted-validation-detail.json) distinguish included/ignored tests. '
    'The final H3-only delta then passed 172 transport unit, 34 H3 and 37 XHTTP tests (243 total), '
    'plus Clippy. Cancelled headers need not reach the peer: the old accepted-request cancellation test '
    'now synchronizes acceptance, and a separate immediate-cancellation test allows either valid wire ordering. '
    'The initial failing test and rejected experiment logs are retained.', '',
    'Canonical vendor reconstruction at `293ac161` verified source archive SHA256, zero-fuzz patches '
    'and exact trees, then ran Quinn 17 (3 ignored), quinn-proto 296 and smoltcp 450 tests. '
    'The final vendor tree is unchanged (`7d2f5c2636b9d97b1179c868f69efb8a500ee9f3`); '
    'this is explicitly inherited validation, not a claim that the whole canonical suite was rerun after the H3-only delta.', '',
    f'- Measured source commit: `{build["source_commit"]}`.',
    f'- Measured source tree: `{build["source_tree"]}`.',
    f'- CLI SHA256: `{build["binary_hashes"]["xray-rust"]}`.',
    f'- Harness SHA256: `{build["binary_hashes"]["xray-bench"]}`.',
    f'- Full patch base: `{build["patch_base"]}`.',
    f'- [Full selected source patch](selected-source.patch) SHA256: `{build["patch_sha256"]}`.',
    '- [Selected build metadata](data/selected-build.json) and [private integration identity](data/delivery-runtime-integration.json).', '',
    'The report/export files are added after timing and are not part of the measured runtime tree. '
    'The delivery verifier reconstructs the exact measured tree from the full patch before installation. '
    'The evidence archive has a per-file SHA256 index and is verified entry by entry. '
    'No benchmark executables are embedded in that archive.', '',
    '## Reproduction and raw evidence', '',
    'Use the [repository protocol-parity instructions](../../../v07-performance.md) '
    'and the archived `run-rc-parity-*.py` drivers. Driver absolute roots must be adjusted to the new host. '
    'Use independently built, immutable binaries with recorded source trees/hashes and one target directory per source root. '
    'Do not overlap measurements with builds, tests, profiling or compression. '
    'Keep common server, payload, MTU, worker settings and network relay parameters identical across clients; '
    'run complete rotated repeated groups, preserving failures and process/relay audits.', '',
    '- [Raw evidence archive](evidence.tar.gz), [SHA256 index](evidence-index.json) and [delivery verification](delivery-verification.json).',
    '- [Every final workload and client](results-index.md), with corresponding JSON in `data/`.',
    '- The archive also retains all earlier interrupted/rejected campaigns and diagnostic samples. '
    'Only the `rc-parity-*` primary groups are counted in the final total above.', '',
]
(out / 'README.md').write_text('\n'.join(lines) + '\n')
print(json.dumps({'report': str(out / 'README.md'), 'groups': len(a['groups']), 'runs': total, 'failed': failed,
                  'strict_target': status, 'external_point_deficits': len(external_deficits)}))

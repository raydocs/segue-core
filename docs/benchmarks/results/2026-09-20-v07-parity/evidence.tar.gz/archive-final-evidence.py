"""Run only after every benchmark process has finished; compression uses CPU."""
from pathlib import Path
import json,tarfile,gzip,hashlib,subprocess
r=Path('/private/tmp/xray-v07-parity-20260920');s=r/'source'
out=s/'docs/benchmarks/results/2026-09-20-v07-parity';out.mkdir(parents=True,exist_ok=True)
required=['verified-local','verified-workers2-control','verified-workers6-control','verified-duplex-long-rtt50','verified-rtt50','verified-hysteria-long-rtt50','verified-legacy','verified-tun','verified-reality','verified-new-tun-long','verified-wireguard-stress-16','verified-wireguard-stress-8','verified-hysteria-long-local','verified-wireguard-long-rtt50']
for name in required:
    p=r/'evidence'/name/'manifest.json';m=json.loads(p.read_text())
    assert m.get('finished_unix'), 'unfinished series: '+name
    assert len(m['runs'])==len(m['cases'])*m['repeats']*len(m['versions']), 'incomplete schedule: '+name
    assert (p.parent/'summary.json').exists(), 'missing summary: '+name
files=set(p for p in (r/'evidence').rglob('*') if p.is_file() and not p.is_symlink())
for pattern in ['*.log','*.json','*.py','*.patch','PROGRESS.md']:
    files.update(p for p in r.glob(pattern) if p.is_file())
for p in (r/'bin').rglob('*'):
    if p.is_file() and not p.is_symlink() and (p.name in {'build.json','source.patch'} or 'runtime-source' in p.parts):files.add(p)
for p in (r/'references').iterdir():
    if p.is_file() and p.suffix in {'.json','.txt'}:files.add(p)
index={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
destination=out/'evidence.tar.gz'
with destination.open('wb') as raw,gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0,compresslevel=6) as compressed,tarfile.open(fileobj=compressed,mode='w|') as archive:
    for p in sorted(files):
        info=archive.gettarinfo(str(p),arcname=str(p.relative_to(r)));info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
        with p.open('rb') as data:archive.addfile(info,data)
(out/'evidence-index.json').write_text(json.dumps({'archive':destination.name,'archive_sha256':hashlib.sha256(destination.read_bytes()).hexdigest(),'file_sha256':index},indent=2)+'\n')
print(json.dumps({'archive':str(destination),'bytes':destination.stat().st_size,'files':len(files)}))

from pathlib import Path
import subprocess,os,shutil,json,time
r=Path('/private/tmp/xray-v07-parity-20260920');s=r/'source';u=r/'gotatun-inplace';rows=[]
env=os.environ.copy();env.update(CARGO_TARGET_DIR='/private/tmp/xray-v07-bench-20260919/build',CARGO_BUILD_JOBS='4')
def run(name,args,red=False):
    start=time.time();print('START',name,flush=True)
    with (r/(name+'.log')).open('w') as f:code=subprocess.call(args,cwd=s,env=env,stdout=f,stderr=subprocess.STDOUT)
    rows.append(dict(name=name,command=args,returncode=code,seconds=time.time()-start));(r/'u-inplace-build.json').write_text(json.dumps(rows,indent=2));print('END',name,code,flush=True)
    if red:
        log=(r/(name+'.log')).read_text()
        assert code!=0 and 'test result: FAILED' in log and 'panicked at' in log and 'bounded encryption allocated a second packet buffer' in log, 'RED must fail the actual reuse assertion'
    elif code:raise SystemExit(code)
test=['cargo','test','--offline','--manifest-path',str(u/'Cargo.toml'),'--no-default-features','--features','ring,device','--lib']
run('u-inplace-red',test+['bounded_encryption_reuses_storage_and_preserves_mtu_payloads'],red=True)
subprocess.run(['python3',str(r/'prepare-u-inplace.py'),'apply'],check=True)
run('u-inplace-fmt',['rustfmt','--edition','2024',str(u/'src/noise/session.rs'),str(u/'src/noise/mod.rs')])
run('u-inplace-green',test)
for name in ['mod.rs','session.rs']:shutil.copy2(u/'src/noise'/name,s/'vendor/gotatun/src/noise'/name)
run('u-inplace-build',['cargo','build','--offline','--release','-p','xray-cli','-p','xray-bench'])

"""Apply packet-specific delivery sampling after deterministic RED proof."""
from pathlib import Path
r = Path('/private/tmp/xray-v07-parity-20260920'); d = r/'quinn-delivery'
assert '0 passed; 2 failed;' in (r/'delivery-sampler-red.log').read_text()
def edit(name, old, new):
    p=d/name; text=p.read_text(); assert text.count(old)==1,(name,old)
    p.write_text(text.replace(old,new))
p=d/'src/congestion/bbr/bw_estimation.rs'
tests=p.read_text().split('#[cfg(test)]',1)[1]
old='''    fn batch_without_previous_ack_time_does_not_define_a_rate() {
        let now = Instant::now();
        let mut b = BandwidthEstimation::default();
        b.on_sent(now, 1200);
        b.on_sent(now + Duration::from_millis(10), 1200);
        for _ in 0..2 {
            b.on_ack(now + Duration::from_millis(20), now, 1200, 1, false);
        }
        assert_eq!(b.get_estimate(), 0);
    }'''
new='''    fn initial_batch_uses_elapsed_delivery_time() {
        let now = Instant::now();
        let mut b = BandwidthEstimation::default();
        b.on_sent(now, 1200);
        b.on_sent(now, 1200);
        for _ in 0..2 {
            b.on_ack(now + Duration::from_millis(20), now, 1200, 1, false);
        }
        assert_eq!(b.get_estimate(), 120_000);
    }'''
assert tests.count(old)==1
tests=tests.replace(old,new)
p.write_text((r/'delivery-sampler-impl.rs').read_text()+'\n#[cfg(test)]'+tests+'\n'+(r/'delivery-sampler-extra-tests.rs').read_text())
edit('src/congestion.rs','    /// Packet deliveries were confirmed\n', '''    /// Record a sent packet with flight state, returning an opaque delivery token.
    ///
    /// The token is returned unchanged in `on_ack_with_token`. The default
    /// preserves controllers implementing only the original callbacks.
    #[allow(unused_variables)]
    fn on_sent_with_in_flight(
        &mut self,
        now: Instant,
        bytes: u64,
        last_packet_number: u64,
        in_flight: u64,
        app_limited: bool,
    ) -> u64 {
        self.on_sent(now, bytes, last_packet_number);
        0
    }

    /// A packet was delivered, with the token recorded when it was sent.
    #[allow(unused_variables)]
    fn on_ack_with_token(
        &mut self,
        now: Instant,
        sent: Instant,
        bytes: u64,
        app_limited: bool,
        rtt: &RttEstimator,
        token: u64,
    ) {
        self.on_ack(now, sent, bytes, app_limited, rtt);
    }

    /// Packet deliveries were confirmed
''')
edit('src/connection/packet_builder.rs','''        if ack_eliciting {
            conn.path.congestion.on_sent(now, size.into(), exact_number);
        }

        let packet = SentPacket {''','''        let delivery_token = if ack_eliciting {
            conn.path.congestion.on_sent_with_in_flight(
                now, size.into(), exact_number, conn.path.in_flight.bytes, conn.app_limited,
            )
        } else {
            0
        };

        let packet = SentPacket {
            delivery_token,''')
edit('src/connection/spaces.rs','pub(super) struct SentPacket {','''pub(super) struct SentPacket {
    /// Opaque congestion-controller delivery state, shared per send batch by BBR.
    pub(super) delivery_token: u64,''')
edit('src/connection/mod.rs','''            self.path.congestion.on_ack(
                now,
                info.time_sent,
                info.size.into(),
                self.app_limited,
                &self.path.rtt,
            );''','''            self.path.congestion.on_ack_with_token(
                now,
                info.time_sent,
                info.size.into(),
                self.app_limited,
                &self.path.rtt,
                info.delivery_token,
            );''')
edit('src/congestion/bbr/mod.rs','    fn enter_startup_mode(&mut self) {','''    fn account_delivery(&mut self, now: Instant, bytes: u64, app_limited: bool, rtt: &RttEstimator) {
        self.acked_bytes += bytes;
        if self.min_rtt.is_zero()
            || self.is_min_rtt_expired(now, app_limited)
            || self.min_rtt > rtt.min()
        {
            self.min_rtt = rtt.min();
        }
    }

    fn enter_startup_mode(&mut self) {''')
edit('src/congestion/bbr/mod.rs','''        self.max_bandwidth
            .on_ack(now, sent, bytes, self.round_count, app_limited);
        self.acked_bytes += bytes;
        if self.min_rtt.is_zero()
            || self.is_min_rtt_expired(now, app_limited)
            || self.min_rtt > rtt.min()
        {
            self.min_rtt = rtt.min();
        }
    }

    fn on_end_acks(''','''        self.max_bandwidth
            .on_ack(now, sent, bytes, self.round_count, app_limited);
        self.account_delivery(now, bytes, app_limited, rtt);
    }

    fn on_sent_with_in_flight(
        &mut self, now: Instant, bytes: u64, last_packet_number: u64,
        in_flight: u64, app_limited: bool,
    ) -> u64 {
        self.max_sent_packet_number = last_packet_number;
        self.max_bandwidth.record_sent(now, bytes, in_flight, app_limited)
    }

    fn on_ack_with_token(
        &mut self, now: Instant, sent: Instant, bytes: u64,
        app_limited: bool, rtt: &RttEstimator, token: u64,
    ) {
        self.max_bandwidth.ack_packet(now, sent, bytes, self.round_count, token);
        self.account_delivery(now, bytes, app_limited, rtt);
    }

    fn on_end_acks(''')
edit('src/congestion/bbr/mod.rs','''        self.max_bandwidth.end_acks(self.round_count, app_limited);''','''        let sample_app_limited = self.max_bandwidth.app_limited_this_window();
        self.max_bandwidth.end_acks(self.round_count, app_limited);''')
edit('src/congestion/bbr/mod.rs','''            self.check_if_full_bw_reached(app_limited);''','''            self.check_if_full_bw_reached(sample_app_limited);''')
print('packet-specific delivery sampler applied', d)

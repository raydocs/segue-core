"""Test and freeze the bounded UDP batch experiment before measuring it."""
from pathlib import Path
import subprocess,os,json,hashlib,shutil,time
r=Path('/private/tmp/xray-v07-parity-20260920');s=r/'wg-send-batch-source';target=Path('/private/tmp/xray-v07-bench-20260919/build')
env=dict(os.environ,CARGO_TARGET_DIR=str(target),CARGO_BUILD_JOBS='4')
for key in ['RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','CARGO_PROFILE_RELEASE_STRIP','CARGO_PROFILE_RELEASE_DEBUG']:
    env.pop(key,None)
rows=[]
for name,cmd in [('wg-send-batch-format',['cargo','fmt','--all']),
                 ('wg-send-batch-unit',['cargo','test','--offline','--release','-p','xray-wireguard','--lib']),
                 ('wg-send-batch-build',['cargo','build','--offline','--release','-p','xray-cli'])]:
    start=time.time();print('START',name,flush=True)
    with (r/(name+'.log')).open('w') as f:code=subprocess.call(cmd,cwd=s,env=env,stdout=f,stderr=subprocess.STDOUT)
    rows.append({'name':name,'returncode':code,'seconds':time.time()-start})
    (r/'wg-send-batch-build.json').write_text(json.dumps(rows,indent=2)+'\n')
    print('END',name,code,flush=True)
    if code:raise SystemExit(code)
subprocess.run(['git','add','crates/xray-wireguard/src/io.rs'],cwd=s,check=True)
subprocess.run(['git','-c','user.name=Codex','-c','user.email=codex@local','commit','-m','Experiment: amortize WireGuard carrier send overhead over bounded available batches'],cwd=s,check=True)
b=r/'bin/wg-send-batch';b.mkdir()
shutil.copy2(target/'release/xray-rust',b/'xray-rust')
patch=subprocess.check_output(['git','diff','--binary','2cefea70f72de26831abd9d85edb414f3acc37cd','HEAD'],cwd=s)
(b/'source.patch').write_bytes(patch)
metadata={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=s,text=True).strip(),
          'source_tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=s,text=True).strip(),
          'clean':not subprocess.check_output(['git','status','--porcelain'],cwd=s,text=True).strip(),
          'patch_base':'2cefea70f72de26831abd9d85edb414f3acc37cd',
          'patch_sha256':hashlib.sha256(patch).hexdigest(),'binary_sha256':hashlib.sha256((b/'xray-rust').read_bytes()).hexdigest(),
          'experimental':True}
(b/'build.json').write_text(json.dumps(metadata,indent=2)+'\n')

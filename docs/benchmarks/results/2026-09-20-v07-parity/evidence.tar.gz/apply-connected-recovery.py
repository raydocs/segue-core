from pathlib import Path
r=Path('/private/tmp/xray-v07-parity-20260920');s=r/'connected-recovery-source'
p=s/'crates/xray-transport/Cargo.toml';t=p.read_text();t+='\n[target.\'cfg(target_os = "macos")\'.dependencies]\nlibc.workspace = true\ntracing = "0.1"\n';p.write_text(t)
p=s/'crates/xray-transport/src/connected_quic.rs';t=p.read_text();t=t.replace('    task::{ready, Context, Poll},','    task::{ready, Context, Poll},\n    time::{Duration, Instant},')
t=t.replace('traffic_class: Mutex::new(traffic_class),','traffic_class: Mutex::new(traffic_class),\n        last_send_error: Mutex::new(None),')
t=t.replace('    traffic_class: Mutex<u32>,','    traffic_class: Mutex<u32>,\n    last_send_error: Mutex<Option<Instant>>,')
a='''            let sent = socket.send(transmit.contents)?;
            if sent != transmit.contents.len() {
                return Err(io::Error::new(
                    io::ErrorKind::WriteZero,
                    "incomplete UDP datagram",
                ));
            }
            Ok(())'''
b='''            // Match Quinn UDP: failed datagrams are loss, not a connection
            // failure. In particular a PMTU probe may exceed the route's MTU.
            // WouldBlock still clears Tokio readiness and schedules a retry.
            loop {
                match socket.send(transmit.contents) {
                    Ok(sent) if sent == transmit.contents.len() => return Ok(()),
                    Ok(_) => return Ok(()), // A partial datagram is lost.
                    Err(error) if error.kind() == io::ErrorKind::Interrupted => continue,
                    Err(error) if error.kind() == io::ErrorKind::WouldBlock => return Err(error),
                    Err(error) if error.raw_os_error() == Some(libc::EMSGSIZE) => return Ok(()),
                    Err(error) => {
                        let now = Instant::now();
                        let mut last = self.last_send_error.lock().unwrap_or_else(|e| e.into_inner());
                        if last.is_none_or(|last| now.saturating_duration_since(last) >= Duration::from_secs(60)) {
                            tracing::warn!(%error, peer = %self.peer, "connected QUIC UDP send failed");
                            *last = Some(now);
                        }
                        return Ok(());
                    }
                }
            }'''
assert t.count(a)==1;t=t.replace(a,b)
a='''                Err(error) if error.kind() == io::ErrorKind::WouldBlock => continue,
                Err(error) => return Poll::Ready(Err(error)),'''
b='''                Err(error) if matches!(error.kind(), io::ErrorKind::WouldBlock
                    | io::ErrorKind::Interrupted | io::ErrorKind::ConnectionRefused
                    | io::ErrorKind::ConnectionReset | io::ErrorKind::HostUnreachable
                    | io::ErrorKind::NetworkUnreachable) => continue,
                Err(error) => return Poll::Ready(Err(error)),'''
assert t.count(a)==1;t=t.replace(a,b);p.write_text(t)
print('Applied connected UDP loss/retry semantics; validation required.')

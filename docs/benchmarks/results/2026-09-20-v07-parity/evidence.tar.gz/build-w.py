"""Freeze an uninstrumented QUIC-accounting candidate after RED/GREEN proof."""
from pathlib import Path
import subprocess, os, json, shutil, hashlib, time
r = Path('/private/tmp/xray-v07-parity-20260920')
s = r / 'source'
d = r / 'w-source'
test_log = (r / 'bbr-cwnd-green.log').read_text()
assert 'test result: ok. 270 passed;' in test_log
assert not d.exists()
subprocess.run(['git', 'clone', '--shared', str(s), str(d)], check=True)
subprocess.run(['git', 'checkout', '--detach', '2cefea70f72de26831abd9d85edb414f3acc37cd'], cwd=d, check=True)
paths = ['src/congestion.rs', 'src/congestion/bbr/mod.rs', 'src/connection/mod.rs',
         'src/connection/packet_builder.rs', 'src/tests/mod.rs', 'src/tests/congestion_sent.rs']
for name in paths:
    shutil.copy2(r / 'quinn-exact-sent' / name, d / 'vendor/quinn-proto' / name)
subprocess.run(['git', 'add', 'vendor/quinn-proto'], cwd=d, check=True)
subprocess.run(['git', '-c', 'user.name=Codex', '-c', 'user.email=codex@local', 'commit', '-m',
                'Experiment: exact QUIC congestion send accounting and BBR startup target'], cwd=d, check=True)
target = Path('/private/tmp/xray-v07-bench-20260919/build')
env = dict(os.environ, CARGO_TARGET_DIR=str(target), CARGO_BUILD_JOBS='4')
for key in ['RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'TOKIO_WORKER_THREADS', 'GOMAXPROCS']:
    env.pop(key, None)
start = time.time()
with (r / 'build-w.log').open('w') as log:
    subprocess.run(['cargo', 'build', '--offline', '--release', '-p', 'xray-cli'], cwd=d, env=env,
                   stdout=log, stderr=subprocess.STDOUT, check=True)
b = r / 'bin/w'
b.mkdir()
shutil.copy2(target / 'release/xray-rust', b / 'xray-rust')
patch = subprocess.check_output(['git', 'diff', '--binary', '2cefea70f72de26831abd9d85edb414f3acc37cd', 'HEAD'], cwd=d)
(b / 'source.patch').write_bytes(patch)
metadata = {'source_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=d, text=True).strip(),
            'source_tree': subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=d, text=True).strip(),
            'clean': not subprocess.check_output(['git', 'status', '--porcelain'], cwd=d, text=True).strip(),
            'binary_sha256': hashlib.sha256((b / 'xray-rust').read_bytes()).hexdigest(),
            'patch_base': '2cefea70f72de26831abd9d85edb414f3acc37cd',
            'patch_sha256': hashlib.sha256(patch).hexdigest(), 'seconds': time.time() - start,
            'vendor_provenance_not_regenerated': True, 'experimental': True,
            'rustc': subprocess.check_output(['rustc', '-vV'], text=True)}
(b / 'build.json').write_text(json.dumps(metadata, indent=2) + '\n')
print(json.dumps(metadata, indent=2))

"""Remove only reproducible caches created by this task, after timed runs finish."""
from pathlib import Path
import hashlib,json,shutil,subprocess,time
r=Path('/private/tmp/xray-v07-parity-20260920')
checks={
 'bin/verified-clean/xray-rust':'f46e8ea9f79aa83437318f47a4902034880064daf09af86fce68ad30f6ec7cdd',
 'bin/packet-wakeup-clean/xray-rust':'7b51daa7e726e05228d48a2ea1e9916df88334c673f2dca6206700098f07b0f8',
}
# The two audited clean builds are sufficient to recover working space.
for path,digest in checks.items():assert hashlib.sha256((r/path).read_bytes()).hexdigest()==digest,path
paths=[r/'clean-build/verified',r/'clean-build/packet-wakeup']
for path in paths:
 assert path.resolve().is_relative_to(r.resolve()) and path.name in ('verified','packet-wakeup')
 metadata=json.loads((r/'bin'/(path.name+'-clean')/'build.json').read_text())
 assert metadata['isolated_fresh_target']==str(path),path
 assert (path/'.rustc_info.json').is_file() and (path/'release/.fingerprint').is_dir(),path
 assert hashlib.sha256((path/'release/xray-rust').read_bytes()).hexdigest()==metadata['binary_sha256'],path
before=shutil.disk_usage(r).free
for path in paths:shutil.rmtree(path)
after=shutil.disk_usage(r).free
(r/'clean-build-cache-removal.json').write_text(json.dumps({'removed':[str(p) for p in paths],'frozen_binary_checks':checks,'source_and_evidence_preserved':True,'free_bytes_before':before,'free_bytes_after':after,'time_unix':time.time()},indent=2)+'\n')
print('removed audited reproducible caches, freed MiB',round((after-before)/2**20))

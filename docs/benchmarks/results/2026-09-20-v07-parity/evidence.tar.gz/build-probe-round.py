"""Evaluate one BBR probe-completion change after the primary matrix ends."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import time

r = Path(__file__).resolve().parent
base = r / 'protocol-followup-source'
commit = 'b9577f874b3f102880ae078038855803d85f5d04'
q = r / 'quinn-probe-round'
s = r / 'probe-round-source'
target = r / 'probe-round-build'
out = r / 'bin/probe-round'
primary = json.loads((r / 'reviewed-sequence.json').read_text())
assert primary['all_planned_groups_collected'] and len(primary['groups']) == 22
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=base, text=True).strip() == commit
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=base, text=True).strip()
for p in [q, s, target, out, r / 'quinn-probe-round-test-build']:
    assert not p.exists(), p
env = dict(os.environ, CARGO_BUILD_JOBS='4', CARGO_TARGET_DIR=str(r / 'quinn-probe-round-test-build'))
for key in ['RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'CARGO_PROFILE_RELEASE_DEBUG', 'CARGO_PROFILE_RELEASE_STRIP']:
    env.pop(key, None)
records = []

def run(name, command, cwd=None, expected=0):
    print('START', name, flush=True)
    started = time.time()
    log = r / (name + '.log')
    with log.open('w') as stream:
        code = subprocess.call(command, cwd=cwd, env=env, stdout=stream, stderr=subprocess.STDOUT)
    records.append(dict(name=name, command=command, returncode=code, expected_returncode=expected, seconds=time.time() - started))
    (r / 'probe-round-build-checks.json').write_text(json.dumps(records, indent=2) + '\n')
    print('END', name, code, flush=True)
    assert code == expected, (name, code, expected)
    return log.read_text()

shutil.copytree(base / 'vendor/quinn-proto', q)
p = q / 'src/congestion/bbr/mod.rs'
tests = r'''

#[cfg(test)]
mod probe_rtt_round_regression {
    use super::*;

    fn probing(now: Instant) -> Bbr {
        let mut bbr = Bbr::new(Arc::new(BbrConfig::default()), 1200);
        bbr.mode = Mode::ProbeRtt;
        bbr.is_at_full_bandwidth = true;
        bbr.min_rtt_sample_epoch = Some(now);
        bbr
    }

    #[test]
    fn completed_round_before_deadline_is_remembered() {
        let now = Instant::now();
        let mut bbr = probing(now);
        bbr.maybe_enter_or_exit_probe_rtt(now, false, 0, false);
        bbr.maybe_enter_or_exit_probe_rtt(now + Duration::from_millis(50), true, 0, false);
        bbr.maybe_enter_or_exit_probe_rtt(now + Duration::from_millis(199), false, 0, false);
        assert_eq!(bbr.mode, Mode::ProbeRtt, "the full 200 ms must elapse");
        bbr.maybe_enter_or_exit_probe_rtt(now + Duration::from_millis(200), false, 0, false);
        assert_eq!(bbr.mode, Mode::ProbeBw, "a completed probe round must not be forgotten at the deadline");
    }

    #[test]
    fn timer_and_a_round_after_draining_are_both_required() {
        let now = Instant::now();
        let mut bbr = probing(now);
        bbr.maybe_enter_or_exit_probe_rtt(now, true, 100_000, false);
        assert!(bbr.exit_probe_rtt_at.is_none());
        let drained = now + Duration::from_millis(50);
        bbr.maybe_enter_or_exit_probe_rtt(drained, true, 0, false);
        bbr.maybe_enter_or_exit_probe_rtt(drained + Duration::from_millis(201), false, 0, false);
        assert_eq!(bbr.mode, Mode::ProbeRtt, "a pre-drain round does not complete the probe");
        bbr.maybe_enter_or_exit_probe_rtt(drained + Duration::from_millis(202), true, 0, false);
        assert_eq!(bbr.mode, Mode::ProbeBw);
    }

    #[test]
    fn a_previous_probe_round_does_not_complete_the_next_probe() {
        let now = Instant::now();
        let mut bbr = probing(now);
        bbr.maybe_enter_or_exit_probe_rtt(now, false, 0, false);
        bbr.maybe_enter_or_exit_probe_rtt(now + Duration::from_millis(50), true, 0, false);
        bbr.maybe_enter_or_exit_probe_rtt(now + Duration::from_millis(200), false, 0, false);
        assert_eq!(bbr.mode, Mode::ProbeBw, "first probe must complete after its elapsed timer and round");
        let next = now + Duration::from_secs(11);
        bbr.maybe_enter_or_exit_probe_rtt(next, true, 0, false);
        assert_eq!(bbr.mode, Mode::ProbeRtt);
        bbr.maybe_enter_or_exit_probe_rtt(next + Duration::from_millis(201), false, 0, false);
        assert_eq!(bbr.mode, Mode::ProbeRtt, "each probe needs its own completed round");
        bbr.maybe_enter_or_exit_probe_rtt(next + Duration::from_millis(202), true, 0, false);
        assert_eq!(bbr.mode, Mode::ProbeBw);
    }
}
'''
p.write_text(p.read_text() + tests)
fmt = ['cargo', 'fmt', '--manifest-path', str(q / 'Cargo.toml'), '--all']
run('probe-round-red-format', fmt)
test = ['cargo', 'test', '--offline', '--locked', '--release', '--manifest-path', str(q / 'Cargo.toml'), '--no-default-features', '--features', 'rustls-ring', '--lib']
red = run('probe-round-red', test + ['probe_rtt_round_regression', '--', '--nocapture'], expected=101)
assert '1 passed; 2 failed;' in red and 'completed probe round must not be forgotten' in red
text = p.read_text()
field = '    exit_probe_rtt_at: Option<Instant>,\n'
init = '            exit_probe_rtt_at: None,\n'
timer = '                        self.exit_probe_rtt_at = Some(now + K_PROBE_RTT_TIME);\n'
for needle in [field, init, timer]:
    assert text.count(needle) == 1, needle
text = text.replace(field, field + '    probe_rtt_round_passed: bool,\n')
text = text.replace(init, init + '            probe_rtt_round_passed: false,\n')
text = text.replace(timer, timer + '                        self.probe_rtt_round_passed = false;\n')
old = '''                Some(exit_time) if is_round_start && now >= exit_time => {
                    self.min_rtt_sample_epoch = Some(now);
                    if !self.is_at_full_bandwidth {
                        self.enter_startup_mode();
                    } else {
                        self.enter_probe_bandwidth_mode(now);
                    }
                }
                Some(_) => {}'''
new = '''                Some(exit_time) => {
                    // The low-flight interval needs both 200 ms and a round.
                    // A round completed before the deadline still counts.
                    self.probe_rtt_round_passed |= is_round_start;
                    if self.probe_rtt_round_passed && now >= exit_time {
                        self.min_rtt_sample_epoch = Some(now);
                        if !self.is_at_full_bandwidth {
                            self.enter_startup_mode();
                        } else {
                            self.enter_probe_bandwidth_mode(now);
                        }
                    }
                }'''
assert text.count(old) == 1
p.write_text(text.replace(old, new))
run('probe-round-green-format', fmt)
green = run('probe-round-green', test)
assert '301 passed; 0 failed;' in green

# A forgotten reset must fail the second-probe test. Restore the exact green
# source before it is copied into the clean full repository.
green_source = p.read_bytes()
mutation = green_source.replace(b'                        self.probe_rtt_round_passed = false;\n', b'')
assert mutation != green_source
p.write_bytes(mutation)
try:
    result = run('probe-round-reset-mutation', test + ['probe_rtt_round_regression::a_previous_probe_round_does_not_complete_the_next_probe', '--', '--nocapture'], expected=101)
    assert '0 passed; 1 failed;' in result and 'each probe needs its own completed round' in result
finally:
    p.write_bytes(green_source)
assert p.read_bytes() == green_source
run('probe-round-clone', ['git', 'clone', '--no-local', str(base), str(s)])
run('probe-round-branch', ['git', 'switch', '-c', 'codex/bbr-probe-round'], s)
shutil.copy2(p, s / 'vendor/quinn-proto/src/congestion/bbr/mod.rs')
assert subprocess.check_output(['git', 'diff', '--name-only'], cwd=s, text=True).splitlines() == ['vendor/quinn-proto/src/congestion/bbr/mod.rs']
run('probe-round-add', ['git', 'add', 'vendor/quinn-proto/src/congestion/bbr/mod.rs'], s)
run('probe-round-commit', ['git', '-c', 'user.name=Codex', '-c', 'user.email=codex@local', 'commit', '-m', 'Complete BBR RTT probes after elapsed time and a completed round'], s)
env['CARGO_TARGET_DIR'] = str(target)
run('probe-round-build', ['cargo', 'build', '--offline', '--locked', '--release', '-p', 'xray-cli'], s)
out.mkdir()
shutil.copy2(target / 'release/xray-rust', out / 'xray-rust')
patch = subprocess.check_output(['git', 'diff', '--binary', commit, 'HEAD'], cwd=s)
(out / 'source.patch').write_bytes(patch)
metadata = dict(
    source_commit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=s, text=True).strip(),
    source_tree=subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=s, text=True).strip(),
    clean=not subprocess.check_output(['git', 'status', '--porcelain'], cwd=s, text=True).strip(),
    parent_commit=commit, patch_base=commit,
    patch_sha256=hashlib.sha256(patch).hexdigest(),
    binary_sha256=hashlib.sha256((out / 'xray-rust').read_bytes()).hexdigest(),
    isolated_fresh_target=str(target), experimental=True,
    vendor_provenance_not_regenerated=True,
    validation='301 quinn-proto tests on exact source; two prior-behavior failures and one reset mutation failure retained',
    reference='Native Hysteria bbr_sender.go maybeEnterOrExitProbeRtt; Linux net/ipv4/tcp_bbr.c bbr_update_min_rtt',
    purpose='Evaluate remembering a completed low-flight round until the 200 ms deadline. No performance gain assumed; short-transfer deficits remain separate.',
)
(out / 'build.json').write_text(json.dumps(metadata, indent=2) + '\n')
print(json.dumps(metadata, indent=2), flush=True)
